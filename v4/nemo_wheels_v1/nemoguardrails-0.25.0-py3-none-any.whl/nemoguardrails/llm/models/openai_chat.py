# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
from typing import Any, AsyncIterator, Dict, List, Optional, Union

from nemoguardrails.exceptions import LLMClientError, LLMResponseValidationError
from nemoguardrails.llm.clients.base import HTTPResponse
from nemoguardrails.llm.clients.openai_compatible import OpenAICompatibleClient
from nemoguardrails.llm.openai_reasoning import apply_openai_reasoning_overrides, is_openai_reasoning_model
from nemoguardrails.types import (
    ChatMessage,
    FinishReason,
    LLMResponse,
    LLMResponseChunk,
    ToolCall,
    ToolCallDelta,
    ToolCallFunction,
    ToolCallFunctionDelta,
    UsageInfo,
)

_KNOWN_PROVIDER_URLS: Dict[str, str] = {
    "https://api.openai.com/v1": "openai",
    "https://integrate.api.nvidia.com/v1": "nim",
}

_FINISH_REASON_MAP: Dict[str, FinishReason] = {
    "stop": "stop",
    "length": "length",
    "tool_calls": "tool_calls",
    "content_filter": "content_filter",
}

_STANDARD_RESPONSE_KEYS = frozenset({"model", "choices", "usage", "id", "object", "created"})


class OpenAIChatModel:
    def __init__(
        self,
        client: OpenAICompatibleClient,
        model: str,
        *,
        provider_name: Optional[str] = None,
        **kwargs: Any,
    ):
        self._client = client
        self._model = model
        if provider_name is None:
            provider_name = _KNOWN_PROVIDER_URLS.get(client.provider_url or "", "openai")
        self._provider_name = provider_name
        self._default_kwargs = kwargs

    @property
    def model_name(self) -> str:
        return self._model

    @property
    def provider_name(self) -> str:
        return self._provider_name

    @property
    def provider_url(self) -> Optional[str]:
        return self._client.provider_url

    def _enrich(self, exc: LLMClientError) -> LLMClientError:
        exc.provider_name = self._provider_name
        exc.model_name = self._model
        exc.base_url = self._client.provider_url
        return exc

    def _prepare_params(self, stop: Optional[List[str]], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        merged = {**self._default_kwargs, **kwargs}
        if stop is not None:
            merged["stop"] = stop
        if is_openai_reasoning_model(self._model):
            merged = apply_openai_reasoning_overrides(merged)
        return merged

    def _to_messages(self, prompt: Union[str, List[ChatMessage]]) -> List[Dict[str, Any]]:
        if isinstance(prompt, str):
            return [{"role": "user", "content": prompt}]
        result = []
        for msg in prompt:
            d = msg.to_dict()
            d.pop("provider_metadata", None)
            if "tool_calls" in d:
                for tc in d["tool_calls"]:
                    func = tc.get("function", {})
                    if isinstance(func.get("arguments"), dict):
                        func["arguments"] = json.dumps(func["arguments"])
            result.append(d)
        return result

    async def generate_async(
        self,
        prompt: Union[str, List[ChatMessage]],
        *,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> LLMResponse:
        messages = self._to_messages(prompt)
        params = self._prepare_params(stop, kwargs)
        try:
            response = await self._client.chat_completion(self._model, messages, **params)
            return self._parse_response(response)
        except LLMClientError as exc:
            raise self._enrich(exc)

    async def stream_async(
        self,
        prompt: Union[str, List[ChatMessage]],
        *,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> AsyncIterator[LLMResponseChunk]:
        messages = self._to_messages(prompt)
        params = self._prepare_params(stop, kwargs)

        tool_call_acc: Dict[int, Dict[str, Any]] = {}

        gen = self._client.stream_chat_completion(self._model, messages, **params)
        try:
            async for chunk_response in gen:
                tool_call_deltas = []
                chunk_body = chunk_response.body
                choices = chunk_body.get("choices", [])
                if choices:
                    delta = choices[0].get("delta", {})
                    raw_tool_calls = delta.get("tool_calls")
                    if raw_tool_calls:
                        for tc_delta in raw_tool_calls:
                            idx = tc_delta.get("index", 0)
                            function = tc_delta.get("function")
                            tool_call_deltas.append(
                                ToolCallDelta(
                                    index=idx,
                                    id=tc_delta.get("id"),
                                    type=tc_delta.get("type"),
                                    function=ToolCallFunctionDelta(
                                        name=function.get("name"), arguments=function.get("arguments")
                                    )
                                    if function is not None
                                    else None,
                                )
                            )
                            if idx not in tool_call_acc:
                                tool_call_acc[idx] = {
                                    "id": "",
                                    "type": tc_delta.get("type", "function"),
                                    "function_name": "",
                                    "arguments_buffer": "",
                                }
                            tool_call_acc[idx]["id"] += tc_delta.get("id") or ""
                            tool_call_acc[idx]["function_name"] += (function or {}).get("name") or ""
                            if tc_delta.get("type"):
                                tool_call_acc[idx]["type"] = tc_delta["type"]
                            arg_fragment = (function or {}).get("arguments", "")
                            if arg_fragment:
                                tool_call_acc[idx]["arguments_buffer"] += arg_fragment

                chunk = self._parse_chunk(chunk_response)
                if chunk is None:
                    continue

                chunk.tool_call_deltas = tool_call_deltas or None
                if chunk.finish_reason in ("tool_calls", "stop") and tool_call_acc:
                    chunk.delta_tool_calls = self._finalize_tool_calls(tool_call_acc)
                    tool_call_acc.clear()

                yield chunk
        except LLMClientError as exc:
            raise self._enrich(exc)
        finally:
            await gen.aclose()

    @staticmethod
    def _finalize_tool_calls(acc: Dict[int, Dict[str, Any]]) -> List[ToolCall]:
        """Parse assembled calls using the same validation as buffered responses."""
        result = []
        for idx in sorted(acc.keys()):
            entry = acc[idx]
            result.append(
                OpenAIChatModel._parse_tool_call(
                    {
                        "id": entry["id"],
                        "type": entry["type"],
                        "function": {
                            "name": entry["function_name"],
                            "arguments": entry["arguments_buffer"],
                        },
                    }
                )
            )
        return result

    def _validate_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        ctx = dict(
            model_name=self.model_name,
            provider_name=self.provider_name,
            base_url=self.provider_url,
        )
        if not isinstance(data, dict):
            raise LLMResponseValidationError(
                f"Expected dict response, got {type(data).__name__}", response_data=None, **ctx
            )
        choices = data.get("choices")
        if not isinstance(choices, list) or not choices:
            raise LLMResponseValidationError(
                f"Missing or empty 'choices' in response: {list(data.keys())}", response_data=data, **ctx
            )
        choice = choices[0]
        if not isinstance(choice, dict):
            raise LLMResponseValidationError(
                f"Expected dict in choices[0], got {type(choice).__name__}", response_data=data, **ctx
            )
        message = choice.get("message")
        if not isinstance(message, dict):
            raise LLMResponseValidationError("Missing or invalid 'message' in choices[0]", response_data=data, **ctx)
        return message

    def _parse_response(self, response: HTTPResponse) -> LLMResponse:
        data = response.body
        message = self._validate_response(data)
        choice = data["choices"][0]

        content = message.get("content") or ""
        reasoning = message.get("reasoning_content")

        tool_calls = None
        raw_tool_calls = message.get("tool_calls")
        if raw_tool_calls:
            tool_calls = [self._parse_tool_call(tc) for tc in raw_tool_calls]

        raw_finish = choice.get("finish_reason")
        finish_reason = _FINISH_REASON_MAP.get(raw_finish, "other") if raw_finish else None

        usage = None
        raw_usage = data.get("usage")
        if raw_usage:
            input_tokens = raw_usage.get("prompt_tokens", 0)
            output_tokens = raw_usage.get("completion_tokens", 0)
            usage = UsageInfo(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=raw_usage.get("total_tokens") or (input_tokens + output_tokens),
                reasoning_tokens=(raw_usage.get("completion_tokens_details") or {}).get("reasoning_tokens"),
                cached_tokens=(raw_usage.get("prompt_tokens_details") or {}).get("cached_tokens"),
            )

        provider_metadata = {k: v for k, v in data.items() if k not in _STANDARD_RESPONSE_KEYS and v is not None}

        if response.headers:
            provider_metadata["response_headers"] = dict(response.headers)

        return LLMResponse(
            content=content,
            reasoning=reasoning,
            tool_calls=tool_calls,
            model=data.get("model"),
            finish_reason=finish_reason,
            request_id=data.get("id"),
            usage=usage,
            provider_metadata=provider_metadata or None,
        )

    def _parse_chunk(self, response: HTTPResponse) -> Optional[LLMResponseChunk]:
        data = response.body
        provider_metadata = {k: v for k, v in data.items() if k not in _STANDARD_RESPONSE_KEYS and v is not None}
        if response.headers:
            provider_metadata["response_headers"] = dict(response.headers)

        usage = None
        raw_usage = data.get("usage")
        if raw_usage:
            input_tokens = raw_usage.get("prompt_tokens", 0)
            output_tokens = raw_usage.get("completion_tokens", 0)
            usage = UsageInfo(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=raw_usage.get("total_tokens") or (input_tokens + output_tokens),
                reasoning_tokens=(raw_usage.get("completion_tokens_details") or {}).get("reasoning_tokens"),
                cached_tokens=(raw_usage.get("prompt_tokens_details") or {}).get("cached_tokens"),
            )

        choices = data.get("choices", [])
        if not choices:
            if usage:
                return LLMResponseChunk(
                    request_id=data.get("id"),
                    usage=usage,
                    provider_metadata=provider_metadata or None,
                )
            return None

        choice = choices[0]
        delta = choice.get("delta", {})

        content = delta.get("content")
        reasoning = delta.get("reasoning_content")
        raw_finish = choice.get("finish_reason")
        finish_reason = _FINISH_REASON_MAP.get(raw_finish, "other") if raw_finish else None

        return LLMResponseChunk(
            delta_content=content,
            delta_reasoning=reasoning,
            model=data.get("model"),
            finish_reason=finish_reason,
            request_id=data.get("id"),
            usage=usage,
            provider_metadata=provider_metadata or None,
        )

    @staticmethod
    def _parse_tool_arguments(raw_args: Any) -> Dict[str, Any]:
        """Accept empty argument strings for compatibility with no-argument calls."""
        if raw_args == "":
            return {}
        try:
            args_dict = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
        except json.JSONDecodeError as exc:
            raise LLMResponseValidationError("Tool call arguments must be a valid JSON object") from exc
        if not isinstance(args_dict, dict):
            raise LLMResponseValidationError("Tool call arguments must be a valid JSON object")
        return args_dict

    @staticmethod
    def _parse_tool_call(tc: Dict[str, Any]) -> ToolCall:
        func = tc.get("function", {})
        return ToolCall(
            id=tc.get("id", ""),
            type=tc.get("type", "function"),
            function=ToolCallFunction(
                name=func.get("name", ""),
                arguments=OpenAIChatModel._parse_tool_arguments(func.get("arguments", "")),
            ),
        )
