# SPDX-FileCopyrightText: Copyright (c) 2023-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Generation options give more control over the generation and the result.

For example, to run only the input rails::

    # Since everything is enabled by default, we disable explicitly the others
    options = {
        "rails": {
            "output": False,
            "dialog": False,
            "retrieval": False
        }
    }
    messages = [{
        "role": "user",
        "content": "Am I allowed to say this?"
    }]

    rails.generate(messages=messages, options=options)

To invoke only some specific input/output rails:

    rails.generate(messages=messages, options={
        "rails": {
            "input": ["check jailbreak"],
            "output": ["output moderation v2"]
        }
    })

To provide additional parameters to the main LLM call:

    rails.generate(messages=messages, options={
        "llm_params": {
            "temperature": 0.5
        }
    })

To return additional information from the generation (i.e., context variables):

    # This will include the relevant chunks in the returned response, as part
    # of the `output_data` field.
    rails.generate(messages=messages, options={
        "output_vars": ["relevant_chunks"]
    })

To skip enforcing the rails, and only inform the user if they were triggered:

    rails.generate(messages=messages, options={
        "enforce": False
    })

    # {..., log: {"triggered_rails": {"type": "input", "name": "check jailbreak"}}}

To get more details on the LLM calls that were executed, including the raw responses:

    rails.generate(messages=messages, options={
        "log": {
            "llm_calls": True
        }
    })

    # {..., log: {"llm_calls": [...]}}

"""

import warnings
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from nemoguardrails.logging.explain import LLMCallInfo


class RailType(str, Enum):
    INPUT = "input"
    OUTPUT = "output"
    # Tool rail types run on the IORails engine only; LLMRails check() rejects them.
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"


TOOL_RAIL_TYPES = frozenset({RailType.TOOL_CALL, RailType.TOOL_RESULT})


class RailStatus(str, Enum):
    PASSED = "passed"
    MODIFIED = "modified"
    BLOCKED = "blocked"


class RailsResult(BaseModel):
    status: RailStatus = Field(description="Status of the rails check: passed, modified, or blocked.")
    content: str = Field(description="The content after rails processing.")
    rail: Optional[str] = Field(default=None, description="Name of the rail that blocked the content.")
    reason: Optional[str] = Field(
        default=None,
        description="Why the rail blocked the content, when the engine reports it (IORails).",
    )
    tool_violations: Optional[List["ToolViolation"]] = Field(
        default=None,
        description="The tool calls or tool results a tool rail blocked (IORails). None unless a tool rail blocked.",
    )


class ToolViolationType(str, Enum):
    """What a blocked tool call or tool result violated; callers switch on this, never on the reason text."""

    # Tool calls
    TOOL_NOT_ALLOWED = "tool_not_allowed"
    ARGUMENTS_INVALID = "arguments_invalid"
    UNEXPECTED_ARGUMENTS = "unexpected_arguments"
    INVALID_TOOL_SCHEMA = "invalid_tool_schema"
    MALFORMED_ARGUMENTS = "malformed_arguments"
    MALFORMED_TOOL_CALL = "malformed_tool_call"
    LEGACY_FUNCTION_CALL = "legacy_function_call"
    INVALID_TOOLSET = "invalid_toolset"
    # Tool results
    MISSING_CALL_ID = "missing_call_id"
    UNKNOWN_CALL_ID = "unknown_call_id"
    DUPLICATE_RESULT = "duplicate_result"
    DUPLICATE_PRIOR_CALL_ID = "duplicate_prior_call_id"
    NAME_MISMATCH = "name_mismatch"
    MALFORMED_CONTENT = "malformed_content"
    UNLINKABLE_RESULT = "unlinkable_result"
    # Either direction
    EXTRACTION_FAILED = "extraction_failed"
    RAIL_FAILED = "rail_failed"
    PER_TOOL_RAIL = "per_tool_rail"


# A tool name or call id is text the model or the caller chose, so a reason or violation keeps at most this much of it.
MAX_QUOTED_IDENTITY_LENGTH = 64


class ToolViolation(BaseModel):
    """One tool call or tool result a tool rail blocked, identified so a caller can act on it."""

    model_config = ConfigDict(frozen=True)

    kind: Literal["tool_call", "tool_result"] = Field(description="Whether a tool call or a tool result was blocked.")
    violation_type: ToolViolationType = Field(
        description="What the call or result violated. Switch on this, never on `reason`."
    )
    reason: str = Field(description="Why it was blocked. Never contains argument values or tool-result content.")
    tool_call_id: Optional[str] = Field(default=None, description="The call's id, or the id the result links to.")
    tool_name: Optional[str] = Field(
        default=None, description="The tool called. For a result, taken from the call it links to."
    )
    index: Optional[int] = Field(
        default=None,
        description="For a call, its position in the last assistant message's `tool_calls`. "
        "For a result, its message's position in `messages`.",
    )
    argument_path: Optional[str] = Field(
        default=None, description="JSON Pointer to the failing argument (`arguments_invalid` only)."
    )
    schema_keyword: Optional[str] = Field(
        default=None, description="The JSON Schema keyword that failed (`arguments_invalid` only)."
    )
    rail: Optional[str] = Field(
        default=None, description="The rail that blocked or failed (`per_tool_rail` and `rail_failed` only)."
    )

    @field_validator("tool_call_id", "tool_name", mode="before")
    @classmethod
    def _string_identity_or_none(cls, value: Any) -> Optional[str]:
        """Store a non-string id or name as None, so a malformed message cannot break building its violation."""
        return value if isinstance(value, str) else None

    @field_validator("tool_name")
    @classmethod
    def _capped_tool_name(cls, value: Optional[str]) -> Optional[str]:
        """Cut a tool name to ``MAX_QUOTED_IDENTITY_LENGTH`` characters, since an undeclared one is model-made."""
        # The call id stays whole: it is the identity a harness matches the violation on.
        if value is None or len(value) <= MAX_QUOTED_IDENTITY_LENGTH:
            return value
        return value[:MAX_QUOTED_IDENTITY_LENGTH] + "..."


class GenerationLogOptions(BaseModel):
    """Options for what should be included in the generation log."""

    activated_rails: bool = Field(
        default=False,
        description="Include detailed information about the rails that were activated during generation.",
    )
    llm_calls: bool = Field(
        default=False,
        description="Include information about all the LLM calls that were made. "
        "This includes: prompt, completion, token usage, raw response, etc.",
    )
    internal_events: bool = Field(
        default=False,
        description="Include the array of internal generated events.",
    )
    colang_history: bool = Field(
        default=False,
        description="Include the history of the conversation in Colang format.",
    )


DEPRECATED_TOOL_RAIL_FIELDS = {"tool_output": "tool_call", "tool_input": "tool_result"}


class GenerationRailsOptions(BaseModel):
    """Options for what rails should be used during the generation."""

    input: Union[bool, List[str]] = Field(
        default=True,
        description="Whether the input rails are enabled or not. "
        "If a list of names is specified, then only the specified input rails will be applied.",
    )
    output: Union[bool, List[str]] = Field(
        default=True,
        description="Whether the output rails are enabled or not. "
        "If a list of names is specified, then only the specified output rails will be applied.",
    )
    retrieval: Union[bool, List[str]] = Field(
        default=True,
        description="Whether the retrieval rails are enabled or not. "
        "If a list of names is specified, then only the specified retrieval rails will be applied.",
    )
    dialog: bool = Field(
        default=True,
        description="Whether the dialog rails are enabled or not.",
    )
    tool_call: Union[bool, List[str]] = Field(
        default=True,
        description="Whether the tool call rails are enabled or not. "
        "If a list of names is specified, then only the specified tool call rails will be applied.",
    )
    tool_result: Union[bool, List[str]] = Field(
        default=True,
        description="Whether the tool result rails are enabled or not. "
        "If a list of names is specified, then only the specified tool result rails will be applied.",
    )
    tool_output: Union[bool, List[str]] = Field(
        default=True,
        deprecated="Use 'tool_call' instead. This field will be removed in a future version.",
        description="DEPRECATED: Use tool_call instead.",
        exclude=True,
    )
    tool_input: Union[bool, List[str]] = Field(
        default=True,
        deprecated="Use 'tool_result' instead. This field will be removed in a future version.",
        description="DEPRECATED: Use tool_result instead.",
        exclude=True,
    )

    @model_validator(mode="before")
    @classmethod
    def migrate_deprecated_tool_rail_fields(cls, values: Any) -> Any:
        if not isinstance(values, dict):
            return values

        values = dict(values)
        for deprecated_name, canonical_name in DEPRECATED_TOOL_RAIL_FIELDS.items():
            if deprecated_name not in values:
                continue
            if canonical_name in values:
                raise ValueError(
                    f"Cannot configure both rails.{deprecated_name} and rails.{canonical_name}; "
                    f"use rails.{canonical_name}."
                )
            warnings.warn(
                f"rails.{deprecated_name} is deprecated; use rails.{canonical_name} instead.",
                DeprecationWarning,
                stacklevel=3,
            )
            values[canonical_name] = values.pop(deprecated_name)
        return values

    @model_validator(mode="after")
    def sync_deprecated_tool_rail_fields(self) -> "GenerationRailsOptions":
        self._sync_deprecated_tool_rail_fields()
        return self

    def _sync_deprecated_tool_rail_fields(self) -> None:
        for deprecated_name, canonical_name in DEPRECATED_TOOL_RAIL_FIELDS.items():
            self.__dict__[deprecated_name] = self.__dict__[canonical_name]

    def __setattr__(self, name: str, value: Any) -> None:
        # The engine reads only the canonical fields, so a write to a deprecated name must land there.
        canonical_name = DEPRECATED_TOOL_RAIL_FIELDS.get(name)
        if canonical_name is not None:
            warnings.warn(
                f"rails.{name} is deprecated; use rails.{canonical_name} instead.", DeprecationWarning, stacklevel=2
            )
            name = canonical_name
        super().__setattr__(name, value)
        self._sync_deprecated_tool_rail_fields()


class GenerationOptions(BaseModel):
    """A set of options that should be applied during a generation.

    The GenerationOptions control various things such as what rails are enabled,
    additional parameters for the main LLM, whether the rails should be enforced or
    ran in parallel, what to be included in the generation log, etc.
    """

    rails: GenerationRailsOptions = Field(
        default_factory=GenerationRailsOptions,
        description="Options for which rails should be applied for the generation. By default, all rails are enabled.",
    )
    llm_params: Optional[dict] = Field(
        default=None,
        description="Additional parameters that should be used for the LLM call",
    )
    llm_output: bool = Field(
        default=False,
        description="Whether the response should also include any custom LLM output.",
    )
    output_vars: Optional[Union[bool, List[str]]] = Field(
        default=None,
        description="Whether additional context information should be returned. "
        "When True is specified, the whole context is returned. "
        "Otherwise, a list of key names can be specified.",
    )
    # TODO: add support for this
    # enforce: Optional[bool] = Field(
    #     default=True,
    #     description="Whether the rails configuration should be enforced. "
    #     "When set to False, the raw LLM call is made in parallel with running the input rails "
    #     "on the user input. Also, the output rails are applied to the output of the raw",
    # )
    log: GenerationLogOptions = Field(
        default_factory=GenerationLogOptions,
        description="Options about what to include in the log. By default, nothing is included. ",
    )

    @model_validator(mode="before")
    @classmethod
    def check_fields(cls, values):
        # Translate the `rails` generation option from List[str] to dict.
        if "rails" in values and isinstance(values["rails"], list):
            _rails = {
                "input": False,
                "dialog": False,
                "retrieval": False,
                "output": False,
                "tool_call": False,
                "tool_result": False,
            }
            for rail_type in values["rails"]:
                canonical_name = DEPRECATED_TOOL_RAIL_FIELDS.get(rail_type)
                if canonical_name is not None:
                    warnings.warn(
                        f"rails.{rail_type} is deprecated; use rails.{canonical_name} instead.",
                        DeprecationWarning,
                        stacklevel=3,
                    )
                    rail_type = canonical_name
                _rails[rail_type] = True
            values["rails"] = _rails

        return values


class ExecutedAction(BaseModel):
    """Information about an action that was executed."""

    action_name: str = Field(description="The name of the action that was executed.")
    action_params: Dict[str, Any] = Field(default_factory=dict, description="The parameters for the action.")
    return_value: Any = Field(default=None, description="The value returned by the action.")
    llm_calls: List[LLMCallInfo] = Field(
        default_factory=list,
        description="Information about the LLM calls made by the action.",
    )
    started_at: Optional[float] = Field(default=None, description="Timestamp for when the action started.")
    finished_at: Optional[float] = Field(default=None, description="Timestamp for when the action finished.")
    duration: Optional[float] = Field(default=None, description="How long the action took to execute, in seconds.")


class ActivatedRail(BaseModel):
    """A rail that was activated during the generation."""

    type: str = Field(description="The type of the rail that was activated, e.g., input, output, dialog.")
    name: str = Field(description="The name of the rail, i.e., the name of the flow implementing the rail.")
    decisions: List[str] = Field(
        default_factory=list,
        description="A sequence of decisions made by the rail, e.g., 'bot refuse to respond', 'stop', 'continue'.",
    )
    executed_actions: List[ExecutedAction] = Field(
        default_factory=list, description="The list of actions executed by the rail."
    )
    stop: bool = Field(
        default=False,
        description="Whether the rail decided to stop any further processing.",
    )
    additional_info: Optional[dict] = Field(default=None, description="Additional information coming from rail.")
    started_at: Optional[float] = Field(default=None, description="Timestamp for when the rail started.")
    finished_at: Optional[float] = Field(default=None, description="Timestamp for when the rail finished.")
    duration: Optional[float] = Field(
        default=None,
        description="The duration in seconds for applying the rail. "
        "Some rails are applied instantly, e.g., dialog rails, so they don't have a duration.",
    )


class GenerationStats(BaseModel):
    """General stats about the generation."""

    input_rails_duration: Optional[float] = Field(
        default=None,
        description="The time in seconds spent in processing the input rails.",
    )
    dialog_rails_duration: Optional[float] = Field(
        default=None,
        description="The time in seconds spent in processing the dialog rails.",
    )
    generation_rails_duration: Optional[float] = Field(
        default=None,
        description="The time in seconds spent in generation rails.",
    )
    output_rails_duration: Optional[float] = Field(
        default=None,
        description="The time in seconds spent in processing the output rails.",
    )
    total_duration: Optional[float] = Field(default=None, description="The total time in seconds.")
    llm_calls_duration: Optional[float] = Field(default=0, description="The time in seconds spent in LLM calls.")
    llm_calls_count: Optional[int] = Field(default=0, description="The number of LLM calls in total.")
    llm_calls_total_prompt_tokens: Optional[int] = Field(default=0, description="The total number of prompt tokens.")
    llm_calls_total_completion_tokens: Optional[int] = Field(
        default=0, description="The total number of completion tokens."
    )
    llm_calls_total_tokens: Optional[int] = Field(default=0, description="The total number of tokens.")


class GenerationLog(BaseModel):
    """Contains additional logging information associated with a generation call."""

    activated_rails: List[ActivatedRail] = Field(
        default_factory=list,
        description="The list of rails that were activated during generation.",
    )
    stats: GenerationStats = Field(
        default_factory=GenerationStats,
        description="General stats about the generation process.",
    )
    llm_calls: Optional[List[LLMCallInfo]] = Field(
        default=None,
        description="The list of LLM calls that have been made to fulfill the generation request. ",
    )
    internal_events: Optional[List[dict]] = Field(
        default=None, description="The complete sequence of internal events generated."
    )
    colang_history: Optional[str] = Field(
        default=None, description="The Colang history associated with the generation."
    )

    def print_summary(self):
        print("\n# General stats\n")

        if self.stats.total_duration is None:
            print("No stats available")
        else:
            pc = 0
            duration = 0

            print(f"- Total time: {self.stats.total_duration:.2f}s")
            if self.stats.input_rails_duration and self.stats.total_duration:
                _pc = round(100 * self.stats.input_rails_duration / self.stats.total_duration, 2)
                pc += _pc
                duration += self.stats.input_rails_duration

                print(f"  - [{self.stats.input_rails_duration:.2f}s][{_pc}%]: INPUT Rails")
            if self.stats.dialog_rails_duration and self.stats.total_duration:
                _pc = round(100 * self.stats.dialog_rails_duration / self.stats.total_duration, 2)
                pc += _pc
                duration += self.stats.dialog_rails_duration

                print(f"  - [{self.stats.dialog_rails_duration:.2f}s][{_pc}%]: DIALOG Rails")
            if self.stats.generation_rails_duration and self.stats.total_duration:
                _pc = round(
                    100 * self.stats.generation_rails_duration / self.stats.total_duration,
                    2,
                )
                pc += _pc
                duration += self.stats.generation_rails_duration

                print(f"  - [{self.stats.generation_rails_duration:.2f}s][{_pc}%]: GENERATION Rails")
            if self.stats.output_rails_duration and self.stats.total_duration:
                _pc = round(100 * self.stats.output_rails_duration / self.stats.total_duration, 2)
                pc += _pc
                duration += self.stats.output_rails_duration

                print(f"  - [{self.stats.output_rails_duration:.2f}s][{_pc}%]: OUTPUT Rails")

            processing_overhead = self.stats.total_duration - duration
            if processing_overhead >= 0.01:
                _pc = round(100 - pc, 2)
                print(f"  - [{processing_overhead:.2f}s][{_pc}%]: Processing overhead ")

            if self.stats.llm_calls_count:
                dur = f"{self.stats.llm_calls_duration:.2f}s" if self.stats.llm_calls_duration is not None else "n/a"
                print(
                    f"- {self.stats.llm_calls_count} LLM calls, "
                    f"{dur} total duration, "
                    f"{self.stats.llm_calls_total_prompt_tokens} total prompt tokens, "
                    f"{self.stats.llm_calls_total_completion_tokens} total completion tokens, "
                    f"{self.stats.llm_calls_total_tokens} total tokens."
                )

        print("\n# Detailed stats\n")
        for activated_rail in self.activated_rails:
            action_names = ", ".join(action.action_name for action in activated_rail.executed_actions) or "n/a"
            llm_calls_count = 0
            llm_calls_durations = []
            for action in activated_rail.executed_actions:
                llm_calls_count += len(action.llm_calls)
                llm_calls_durations.extend(
                    [
                        f"{round(llm_call.duration, 2)}s"
                        for llm_call in action.llm_calls
                        if llm_call.duration is not None
                    ]
                )
            dur = f"{activated_rail.duration:.2f}s" if activated_rail.duration is not None else "n/a"
            llm_calls_dur = ", ".join(llm_calls_durations) or "n/a"
            print(
                f"- [{dur}] {activated_rail.type.upper()} ({activated_rail.name}): "
                f"{len(activated_rail.executed_actions)} actions ({action_names}), "
                f"{llm_calls_count} llm calls [{llm_calls_dur}]"
            )
        print("\n")


class GenerationResponse(BaseModel):
    # TODO: add typing for the list of messages
    response: Union[str, List[dict]] = Field(description="The list of the generated messages.")
    llm_output: Optional[dict] = Field(default=None, description="Contains any additional output coming from the LLM.")
    output_data: Optional[dict] = Field(
        default=None,
        description="The output data, i.e. a dict with the values corresponding to the `output_vars`.",
    )
    log: Optional[GenerationLog] = Field(default=None, description="Additional logging information.")
    state: Optional[dict] = Field(
        default=None,
        description="A state object which can be used in subsequent calls to continue the interaction.",
    )
    tool_calls: Optional[list] = Field(
        default=None,
        description="Tool calls extracted from the LLM response, if any.",
    )
    reasoning_content: Optional[str] = Field(
        default=None,
        description="The reasoning content extracted from the LLM response, if any.",
    )
    llm_metadata: Optional[dict] = Field(
        default=None,
        description="Metadata from the LLM response (additional_kwargs, response_metadata, usage_metadata, etc.)",
    )


if __name__ == "__main__":
    print(
        GenerationOptions(rails=GenerationRailsOptions(input=False))
    )  # pragma: no cover (Can't run as script for test coverage)
