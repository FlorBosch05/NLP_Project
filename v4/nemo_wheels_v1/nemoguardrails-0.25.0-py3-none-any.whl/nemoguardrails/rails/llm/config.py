# SPDX-FileCopyrightText: Copyright (c) 2023-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Module for the configuration of rails."""

import importlib.metadata
import logging
import os
import warnings
from collections.abc import Collection
from dataclasses import dataclass
from difflib import get_close_matches
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, Iterator, List, Literal, Optional, Set, Tuple, Union

import yaml
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ModelWrapValidatorHandler,
    field_validator,
    model_validator,
)

from nemoguardrails import utils
from nemoguardrails.exceptions import (
    InvalidModelConfigurationError,
    InvalidRailsConfigurationError,
)
from nemoguardrails.library.self_check.utils import get_self_check_prompt_task
from nemoguardrails.rails.llm.options import DEPRECATED_TOOL_RAIL_FIELDS
from nemoguardrails.rails.llm.rails_config_fields import (
    build_rails_config_data,
    config_exported_names,
    resolve_config_export,
    validate_no_config_export_shadowing,
)
from nemoguardrails.utils import _get_flow_params, _normalize_flow_id

if TYPE_CHECKING:
    from nemoguardrails.manifests import RailSurface

log = logging.getLogger(__name__)

# Load the default config values from the file
with open(os.path.join(os.path.dirname(__file__), "default_config.yml")) as _fc:
    _default_config = yaml.safe_load(_fc)

with open(os.path.join(os.path.dirname(__file__), "default_config_v2.yml")) as _fc:
    _default_config_v2 = yaml.safe_load(_fc)

# Jailbreak-related strings
JAILBREAK_FLOW_MODEL = "jailbreak detection model"
JAILBREAK_FLOW_HEURISTICS = "jailbreak detection heuristics"

# Extract the COLANGPATH directories.
colang_path_dirs = [
    _path.strip() for _path in os.environ.get("COLANGPATH", "").split(os.pathsep) if _path.strip() != ""
]

# We also make sure that the standard library is in the COLANGPATH.
standard_library_path = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "..", "colang", "v2_x", "library")
)

# nemoguardrails/library
guardrails_stdlib_path = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
colang_path_dirs.append(standard_library_path)
colang_path_dirs.append(guardrails_stdlib_path)


class CacheStatsConfig(BaseModel):
    """Configuration for cache statistics tracking and logging."""

    enabled: bool = Field(
        default=False,
        description="Whether cache statistics tracking is enabled",
    )
    log_interval: Optional[float] = Field(
        default=None,
        description="Seconds between periodic cache stats logging to logs (None disables logging)",
    )


class ModelCacheConfig(BaseModel):
    """Configuration for model caching."""

    enabled: bool = Field(
        default=False,
        description="Whether caching is enabled (default: False - no caching)",
    )
    maxsize: int = Field(default=50000, description="Maximum number of entries in the cache per model")
    stats: CacheStatsConfig = Field(
        default_factory=CacheStatsConfig,
        description="Configuration for cache statistics tracking and logging",
    )


class Model(BaseModel):
    """Configuration of a model used by the rails engine.

    Typically, the main model is configured e.g.:
    {
        "type": "main",
        "engine": "openai",
        "model": "gpt-4o-mini"
    }
    """

    type: str
    engine: str
    model: Optional[str] = Field(
        default=None,
        description="The name of the model. If not specified, it should be specified through the parameters attribute.",
    )
    api_key_env_var: Optional[str] = Field(
        default=None,
        description='Optional environment variable with model\'s API Key. Do not include "$".',
    )
    parameters: Dict[str, Any] = Field(default_factory=dict)

    mode: Literal["chat", "text"] = Field(
        default="chat",
        description="Whether the mode is 'text' completion or 'chat' completion. Allowed values are 'chat' or 'text'.",
    )

    # Cache configuration specific to this model (for content safety models)
    cache: Optional["ModelCacheConfig"] = Field(
        default=None,
        description="Cache configuration for this specific model (primarily used for content safety models)",
    )

    @model_validator(mode="before")
    @classmethod
    def set_and_validate_model(cls, data: Any) -> Any:
        if isinstance(data, dict):
            parameters = data.get("parameters")
            if parameters is None:
                return data
            model_field = data.get("model")
            model_from_params = parameters.get("model_name") or parameters.get("model")

            if model_field and model_from_params:
                raise InvalidModelConfigurationError(
                    "Model name must be specified in exactly one place: either the `model` field, or in `parameters` (`parameters.model` or `parameters.model_name`).",
                )
            if not model_field and model_from_params:
                data["model"] = model_from_params
                if "model_name" in parameters and parameters["model_name"] == model_from_params:
                    parameters.pop("model_name")
                elif "model" in parameters and parameters["model"] == model_from_params:
                    parameters.pop("model")
            return data

    @model_validator(mode="after")
    def model_must_be_none_empty(self) -> "Model":
        """Validate that a model name is present either directly or in parameters."""
        if not self.model or not self.model.strip():
            raise InvalidModelConfigurationError(
                "Model name must be specified in exactly one place: either the `model` field, or in `parameters` (`parameters.model` or `parameters.model_name`)."
            )
        return self


class Instruction(BaseModel):
    """Configuration for instructions in natural language that should be passed to the LLM."""

    type: str
    content: str


class Document(BaseModel):
    """Configuration for documents that should be used for question answering."""

    format: str
    content: str


class MessageTemplate(BaseModel):
    """Template for a message structure."""

    type: str = Field(description="The type of message, e.g., 'assistant', 'user', 'system'.")
    content: str = Field(description="The content of the message.")


class TaskPrompt(BaseModel):
    """Configuration for prompts that will be used for a specific task."""

    task: str = Field(description="The id of the task associated with this prompt.")
    content: Optional[str] = Field(default=None, description="The content of the prompt, if it's a string.")
    messages: Optional[List[Union[MessageTemplate, str]]] = Field(
        default=None,
        description="The list of messages included in the prompt. Used for chat models.",
    )
    models: Optional[List[str]] = Field(
        default=None,
        description="If specified, the prompt will be used only for the given LLM engines/models. "
        "The format is a list of strings with the format: <engine> or <engine>/<model>.",
    )
    output_parser: Optional[str] = Field(
        default=None,
        description="The name of the output parser to use for this prompt.",
    )
    max_length: Optional[int] = Field(
        default=16000,
        description="The maximum length of the prompt in number of characters.",
        ge=1,
    )
    mode: Optional[str] = Field(
        default=_default_config["prompting_mode"],
        description="Corresponds to the `prompting_mode` for which this prompt is fetched. Default is 'standard'.",
    )
    stop: Optional[List[str]] = Field(
        default=None,
        description="If specified, will be configure stop tokens for models that support this.",
    )

    max_tokens: Optional[int] = Field(
        default=None,
        description="The maximum number of tokens that can be generated in the chat completion.",
        ge=1,
    )

    @model_validator(mode="before")
    @classmethod
    def check_fields(cls, values):
        if not values.get("content") and not values.get("messages"):
            raise InvalidRailsConfigurationError("One of `content` or `messages` must be provided.")

        if values.get("content") and values.get("messages"):
            raise InvalidRailsConfigurationError("Only one of `content` or `messages` must be provided.")

        return values


class LogAdapterConfig(BaseModel):
    name: str = Field(default="FileSystem", description="The name of the adapter.")
    model_config = ConfigDict(extra="allow")


class SpanFormat(str, Enum):
    legacy = "legacy"
    opentelemetry = "opentelemetry"


class TracingConfig(BaseModel):
    enabled: bool = False
    adapters: List[LogAdapterConfig] = Field(
        default_factory=lambda: [LogAdapterConfig()],
        description="The list of tracing adapters to use. If not specified, the default adapters are used.",
    )
    span_format: str = Field(
        default=SpanFormat.opentelemetry,
        description="The span format to use. Options are 'legacy' (simple metrics) or 'opentelemetry' (OpenTelemetry semantic conventions).",
    )
    enable_content_capture: bool = Field(
        default=False,
        description=(
            "Capture prompts and responses (user/assistant/tool message content) in tracing/telemetry events. "
            "Disabled by default for privacy and alignment with OpenTelemetry GenAI semantic conventions. "
            "WARNING: Enabling this may include PII and sensitive data in your telemetry backend. "
            "Behaviour differs by engine. "
            "For IORails — "
            "1. OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT environment variable has highest priority: "
            "'true'/'1' force on, 'false'/'0' force off, for other values this field is used. "
            "2. OTEL_SEMCONV_STABILITY_OPT_IN selects output format: when the comma-separated token list "
            "contains 'gen_ai_latest_experimental', content is emitted as JSON-encoded span attributes "
            "(gen_ai.input.messages, gen_ai.output.messages, gen_ai.system_instructions); "
            "otherwise as legacy per-message span events "
            "(gen_ai.user.message, gen_ai.assistant.message, gen_ai.system.message, gen_ai.choice). "
            "For LLMRails — "
            "Neither OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT nor OTEL_SEMCONV_STABILITY_OPT_IN "
            "are consulted; this field is the only control. "
            "Content is always emitted via the deprecated gen_ai.content.prompt and "
            "gen_ai.content.completion span events."
        ),
    )


class MetricsConfig(BaseModel):
    """OpenTelemetry Metrics Configuration.
    Configures and enables Metrics independent of OTEL Traces.
    """

    enabled: bool = Field(
        default=False,
        description=("Emit OTEL metrics for IORails (independent of tracing)"),
    )


class EmbeddingsCacheConfig(BaseModel):
    """Configuration for the caching embeddings."""

    enabled: bool = Field(
        default=False,
        description="Whether caching of the embeddings should be enabled or not.",
    )
    key_generator: str = Field(
        default="sha256",
        description="The method to use for generating the cache keys.",
    )
    store: str = Field(
        default="filesystem",
        description="What type of store to use for the cached embeddings.",
    )
    store_config: Dict[str, Any] = Field(
        default_factory=dict,
        description="Any additional configuration options required for the store. "
        "For example, path for `filesystem` or `host`/`port`/`db` for redis.",
    )

    def to_dict(self):
        return self.model_dump()


class EmbeddingSearchProvider(BaseModel):
    """Configuration of a embedding search provider."""

    name: str = Field(
        default="default",
        description="The name of the embedding search provider. If not specified, default is used.",
    )
    parameters: Dict[str, Any] = Field(default_factory=dict)
    cache: EmbeddingsCacheConfig = Field(default_factory=EmbeddingsCacheConfig)


class KnowledgeBaseConfig(BaseModel):
    folder: str = Field(
        default="kb",
        description="The folder from which the documents should be loaded.",
    )
    embedding_search_provider: EmbeddingSearchProvider = Field(
        default_factory=EmbeddingSearchProvider,
        description="The search provider used to search the knowledge base.",
    )


class CoreConfig(BaseModel):
    """Settings for core internal mechanics."""

    embedding_search_provider: EmbeddingSearchProvider = Field(
        default_factory=EmbeddingSearchProvider,
        description="The search provider used to search the most similar canonical forms/flows.",
    )


class InputRails(BaseModel):
    """Configuration of input rails."""

    parallel: Optional[bool] = Field(
        default=False,
        description="If True, the input rails are executed in parallel.",
    )

    speculative_generation: Optional[bool] = Field(
        default=False,
        description=(
            "If True, input rails run concurrently with LLM generation (speculative execution). "
            "Only supported for non-streaming generate_async() calls; stream_async() warns and falls "
            "back to sequential execution."
        ),
    )

    flows: List[str] = Field(
        default_factory=list,
        description="The names of all the flows that implement input rails.",
    )


class OutputRailsStreamingConfig(BaseModel):
    """Configuration for managing streaming output of LLM tokens."""

    enabled: bool = Field(default=False, description="Enables streaming mode when True.")
    chunk_size: int = Field(
        default=200,
        description="The number of tokens in each processing chunk. This is the size of the token block on which output rails are applied.",
    )
    context_size: int = Field(
        default=50,
        description="The number of tokens carried over from the previous chunk to provide context for continuity in processing.",
    )
    stream_first: bool = Field(
        default=True,
        description="If True, token chunks are streamed immediately before output rails are applied.",
    )
    model_config = ConfigDict(extra="allow")


class OutputRails(BaseModel):
    """Configuration of output rails."""

    parallel: Optional[bool] = Field(
        default=False,
        description="If True, the output rails are executed in parallel.",
    )

    flows: List[str] = Field(
        default_factory=list,
        description="The names of all the flows that implement output rails.",
    )

    streaming: OutputRailsStreamingConfig = Field(
        default_factory=OutputRailsStreamingConfig,
        description="Configuration for streaming output rails.",
    )


class RetrievalRails(BaseModel):
    """Configuration of retrieval rails."""

    flows: List[str] = Field(
        default_factory=list,
        description="The names of all the flows that implement retrieval rails.",
    )


class ActionRails(BaseModel):
    """Configuration of action rails.

    Action rails control various options related to the execution of actions.
    Currently, only

    In the future multiple options will be added, e.g., what input validation should be
    performed per action, output validation, throttling, disabling, etc.
    """

    instant_actions: Optional[List[str]] = Field(
        default=None,
        description="The names of all actions which should finish instantly.",
    )


class ToolEntry(BaseModel):
    """A tool in `hooks_server.allowed_tools` or `blocked_tools`, named with the arguments its entry is about."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(description="The tool's name, exactly as a tool call spells it.")
    arguments: List[str] = Field(
        min_length=1,
        description="Argument names. In `allowed_tools`, a call may pass only these; "
        "in `blocked_tools`, a call that passes any of them is blocked.",
    )

    @field_validator("arguments")
    @classmethod
    def check_arguments_are_unique(cls, arguments: List[str]) -> List[str]:
        """Refuse an entry that names an argument twice."""
        repeated = sorted({argument for argument in arguments if arguments.count(argument) > 1})
        if repeated:
            raise ValueError(f"arguments names {repeated} more than once; list each argument once")
        return arguments


class HooksServerConfig(BaseModel):
    """The tool policy `nemoguardrails hooks-server` applies to each hook's call; no engine reads it."""

    model_config = ConfigDict(extra="forbid")

    allowed_tools: List[Union[str, ToolEntry]] = Field(
        default_factory=list,
        description="Tools a call may use: a name, which allows any arguments, or a `{name, arguments}` entry, "
        "which allows only those arguments.",
    )
    blocked_tools: List[Union[str, ToolEntry]] = Field(
        default_factory=list,
        description="Tools a call may not use: a name, which blocks every call to the tool, or a `{name, arguments}` "
        "entry, which blocks a call that passes any of those arguments.",
    )
    allow_unlisted_tools: bool = Field(
        default=True,
        description="Whether a call to a tool `allowed_tools` doesn't name is allowed.",
    )

    @model_validator(mode="after")
    def check_tool_lists(self) -> "HooksServerConfig":
        """Refuse tool lists that name a tool twice, or that allow a tool they block by name."""
        for list_name in ("allowed_tools", "blocked_tools"):
            repeated = _first_repeated_tool_name(getattr(self, list_name))
            if repeated is not None:
                raise InvalidRailsConfigurationError(
                    f"hooks_server.{list_name} names tool '{repeated}' more than once; list each tool once."
                )
        blocked_by_name = {entry for entry in self.blocked_tools if isinstance(entry, str)}
        contradicted = [
            _tool_entry_name(entry) for entry in self.allowed_tools if _tool_entry_name(entry) in blocked_by_name
        ]
        if contradicted:
            raise InvalidRailsConfigurationError(
                f"hooks_server.allowed_tools allows tool '{contradicted[0]}', which hooks_server.blocked_tools blocks "
                "by name; remove it from one of the two lists."
            )
        return self

    @property
    def can_deny(self) -> bool:
        """Whether the policy can deny a call: it blocks something, denies unlisted tools, or limits a tool's arguments."""
        # Bare names in allowed_tools deny nothing while unlisted tools are allowed.
        if self.blocked_tools or not self.allow_unlisted_tools:
            return True
        return any(isinstance(entry, ToolEntry) for entry in self.allowed_tools)


class ToolCallRails(BaseModel):
    """Configuration of tool call rails.

    Tool call rails are applied to tool calls before they are executed.
    They can validate tool names, parameters, and context to ensure safe tool usage.
    """

    flows: List[str] = Field(
        default_factory=list,
        description="The names of all the flows that implement tool call rails.",
    )
    per_tool: Dict[str, List[str]] = Field(
        default_factory=dict,
        description="Per-tool flows, keyed by tool name. Supplements the global `flows`, which run for every tool call.",
    )
    parallel: Optional[bool] = Field(
        default=False,
        description="If True, the tool call rails are executed in parallel.",
    )


def _tool_entry_name(entry: Union[str, ToolEntry]) -> str:
    """The tool a list entry names."""
    return entry if isinstance(entry, str) else entry.name


def _first_repeated_tool_name(tool_list: List[Union[str, ToolEntry]]) -> Optional[str]:
    """The first tool *tool_list* names a second time, or None when it names each tool once."""
    seen: Set[str] = set()
    for entry in tool_list:
        name = _tool_entry_name(entry)
        if name in seen:
            return name
        seen.add(name)
    return None


class ToolResultRails(BaseModel):
    """Configuration of tool result rails.

    Tool result rails are applied to tool results before they are processed.
    They can validate, filter, or transform tool results for security and safety.
    """

    flows: List[str] = Field(
        default_factory=list,
        description="The names of all the flows that implement tool result rails.",
    )
    per_tool: Dict[str, List[str]] = Field(
        default_factory=dict,
        description="Per-tool flows, keyed by tool name. Supplements the global `flows`, which run for every tool result.",
    )
    parallel: Optional[bool] = Field(
        default=False,
        description="If True, the tool result rails are executed in parallel.",
    )


ToolOutputRails = ToolCallRails
ToolInputRails = ToolResultRails


class SingleCallConfig(BaseModel):
    """Configuration for the single LLM call option for topical rails."""

    enabled: bool = False
    fallback_to_multiple_calls: bool = Field(
        default=True,
        description="Whether to fall back to multiple calls if a single call is not possible.",
    )


class UserMessagesConfig(BaseModel):
    """Configuration for how the user messages are interpreted."""

    embeddings_only: bool = Field(
        default=False,
        description="Whether to use only embeddings for computing the user canonical form messages.",
    )
    embeddings_only_similarity_threshold: Optional[float] = Field(
        default=None,
        ge=0,
        le=1,
        description="The similarity threshold to use when using only embeddings for computing the user canonical form messages.",
    )
    embeddings_only_fallback_intent: Optional[str] = Field(
        default=None,
        description="Defines the fallback intent when the similarity is below the threshold. If set to None, the user intent is computed normally using the LLM. If set to a string value, that string is used as the intent.",
    )


class DialogRails(BaseModel):
    """Configuration of topical rails."""

    single_call: SingleCallConfig = Field(
        default_factory=SingleCallConfig,
        description="Configuration for the single LLM call option.",
    )
    user_messages: UserMessagesConfig = Field(
        default_factory=UserMessagesConfig,
        description="Configuration for how the user messages are interpreted.",
    )


class _RailsConfigDataBase(BaseModel):
    """Configuration data for specific rails that are supported out-of-the-box."""

    pass


if TYPE_CHECKING:

    class RailsConfigData(_RailsConfigDataBase):
        def __getattr__(self, name: str) -> Any: ...

else:
    RailsConfigData = build_rails_config_data(base=_RailsConfigDataBase, module=__name__)


def __getattr__(name: str):
    try:
        return resolve_config_export(name)
    except KeyError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc


def __dir__():
    return sorted(set(globals()) | set(config_exported_names()))


class Rails(BaseModel):
    """Configuration of specific rails."""

    config: RailsConfigData = Field(  # pyright: ignore[reportInvalidTypeForm]
        default_factory=RailsConfigData,
        description="Configuration data for specific rails that are supported out-of-the-box.",
    )
    input: InputRails = Field(default_factory=InputRails, description="Configuration of the input rails.")
    output: OutputRails = Field(default_factory=OutputRails, description="Configuration of the output rails.")
    retrieval: RetrievalRails = Field(
        default_factory=RetrievalRails,
        description="Configuration of the retrieval rails.",
    )
    dialog: DialogRails = Field(default_factory=DialogRails, description="Configuration of the dialog rails.")
    actions: ActionRails = Field(default_factory=ActionRails, description="Configuration of action rails.")
    tool_call: ToolCallRails = Field(
        default_factory=ToolCallRails,
        description="Configuration of tool call rails.",
    )
    tool_result: ToolResultRails = Field(
        default_factory=ToolResultRails,
        description="Configuration of tool result rails.",
    )
    tool_output: ToolCallRails = Field(
        default_factory=ToolCallRails,
        deprecated="Use 'tool_call' instead. This field will be removed in a future version.",
        description="DEPRECATED: Use tool_call instead.",
        exclude=True,
    )
    tool_input: ToolResultRails = Field(
        default_factory=ToolResultRails,
        deprecated="Use 'tool_result' instead. This field will be removed in a future version.",
        description="DEPRECATED: Use tool_result instead.",
        exclude=True,
    )

    @model_validator(mode="before")
    @classmethod
    def migrate_deprecated_tool_rail_fields(cls, values: Any) -> Any:
        if not isinstance(values, dict):
            return values

        values = dict(values)
        for deprecated_name, canonical_name in DEPRECATED_TOOL_RAIL_FIELDS.items():
            if deprecated_name not in values:
                continue
            if canonical_name in values:
                raise ValueError(
                    f"Cannot configure both rails.{deprecated_name} and rails.{canonical_name}; "
                    f"use rails.{canonical_name}."
                )
            warnings.warn(
                f"rails.{deprecated_name} is deprecated; use rails.{canonical_name} instead.",
                DeprecationWarning,
                stacklevel=3,
            )
            values[canonical_name] = values.pop(deprecated_name)
        return values

    @model_validator(mode="after")
    def sync_deprecated_tool_rail_fields(self) -> "Rails":
        self._sync_deprecated_tool_rail_fields()
        return self

    def _sync_deprecated_tool_rail_fields(self) -> None:
        for deprecated_name, canonical_name in DEPRECATED_TOOL_RAIL_FIELDS.items():
            self.__dict__[deprecated_name] = self.__dict__[canonical_name]

    def __setattr__(self, name: str, value: Any) -> None:
        # The engine reads only the canonical fields, so a write to a deprecated name must land there.
        canonical_name = DEPRECATED_TOOL_RAIL_FIELDS.get(name)
        if canonical_name is not None:
            warnings.warn(
                f"rails.{name} is deprecated; use rails.{canonical_name} instead.", DeprecationWarning, stacklevel=2
            )
            name = canonical_name
        super().__setattr__(name, value)
        self._sync_deprecated_tool_rail_fields()


def merge_two_dicts(dict_1: dict, dict_2: dict, ignore_keys: Set[str]) -> None:
    """Merges the fields of two dictionaries recursively."""
    for key, value in dict_2.items():
        if key not in ignore_keys:
            if key in dict_1:
                if isinstance(dict_1[key], dict) and isinstance(value, dict):
                    merge_two_dicts(dict_1[key], value, set())
                elif dict_1[key] != value:
                    log.warning(
                        "Conflicting fields with same name '%s' in yaml config files detected!",
                        key,
                    )
            else:
                dict_1[key] = value


def _warn_unknown_config_key(key: str, known_keys: Collection[str], path: str = "") -> None:
    full_path = f"{path}.{key}" if path else str(key)
    matches = get_close_matches(str(key), known_keys, n=1, cutoff=0.75)
    suggestion = f" Did you mean '{matches[0]}'?" if matches else ""
    consequence = (
        " This section is unsupported and will not enable execution rails." if full_path == "rails.execution" else ""
    )
    if not path:
        consequence = " This is not a built-in configuration key. Use 'custom_data' for application-specific settings."
    log.warning("Unknown configuration key '%s'.%s%s", full_path, consequence, suggestion)


def _warn_unknown_config_keys(raw: Any, parsed: Any, path: str = "") -> None:
    """Compare with validated values to follow the selected union and preserve open dictionaries."""
    if raw is parsed:
        return
    if isinstance(raw, dict) and isinstance(parsed, BaseModel):
        fields = type(parsed).model_fields
        known_keys = {field.alias or name: name for name, field in fields.items()}
        known_keys.update({name: name for name in fields})
        for key, value in raw.items():
            name = known_keys.get(key)
            if name is None:
                if parsed.model_config.get("extra") != "allow":
                    _warn_unknown_config_key(key, known_keys, path)
                continue
            child_path = f"{path}.{key}" if path else str(key)
            _warn_unknown_config_keys(value, getattr(parsed, name), child_path)
    elif isinstance(raw, dict) and isinstance(parsed, dict):
        for key, value in raw.items():
            if key in parsed:
                _warn_unknown_config_keys(value, parsed[key], f"{path}.{key}")
    elif isinstance(raw, list) and isinstance(parsed, list):
        for index, (value, item) in enumerate(zip(raw, parsed)):
            _warn_unknown_config_keys(value, item, f"{path}[{index}]")


def _join_config(dest_config: dict, additional_config: dict, source: Optional[str] = None):
    """Helper to join two configuration; *source* names where *additional_config* was read from, for errors."""

    dest_config["user_messages"] = {
        **dest_config.get("user_messages", {}),
        **additional_config.get("user_messages", {}),
    }

    dest_config["bot_messages"] = {
        **dest_config.get("bot_messages", {}),
        **additional_config.get("bot_messages", {}),
    }

    dest_config["instructions"] = dest_config.get("instructions", []) + additional_config.get("instructions", [])

    dest_config["flows"] = dest_config.get("flows", []) + additional_config.get("flows", [])

    dest_config["models"] = dest_config.get("models", []) + additional_config.get("models", [])

    dest_config["prompts"] = dest_config.get("prompts", []) + additional_config.get("prompts", [])

    dest_config["docs"] = dest_config.get("docs", []) + additional_config.get("docs", [])

    dest_config["actions_server_url"] = dest_config.get("actions_server_url", None) or additional_config.get(
        "actions_server_url", None
    )

    if "sensitive_data_detection" in additional_config:
        dest_config["sensitive_data_detection"] = {
            **dest_config.get("sensitive_data_detection", {}),
            **additional_config["sensitive_data_detection"],
        }

    if "hooks_server" in additional_config:
        # Replacing one section with another would drop restrictions, and joining them would widen the allowlists.
        if "hooks_server" in dest_config:
            found_again = f" (found again in {source})" if source else ""
            raise ValueError(
                "The hooks_server section is set in more than one file of this config, or of a config it imports; "
                f"set it in one file only{found_again}."
            )
        dest_config["hooks_server"] = additional_config["hooks_server"]

    if "embedding_search_provider" in additional_config:
        dest_config["embedding_search_provider"] = (
            dest_config.get("embedding_search_provider", {}) or additional_config["embedding_search_provider"]
        )

    # We join the arrays and keep only unique elements for import paths.
    dest_config["import_paths"] = dest_config.get("import_paths", [])
    for import_path in additional_config.get("import_paths", []):
        if import_path not in dest_config["import_paths"]:
            dest_config["import_paths"].append(import_path)

    additional_fields = [
        "sample_conversation",
        "lowest_temperature",
        "enable_multi_step_generation",
        "colang_version",
        "event_source_uid",
        "custom_data",
        "prompting_mode",
        "knowledge_base",
        "core",
        "rails",
        "streaming",
        "passthrough",
        "raw_llm_call_action",
        "enable_rails_exceptions",
        "tracing",
        "metrics",
    ]

    for field in additional_fields:
        if field in additional_config:
            dest_config[field] = additional_config[field]

    # TODO: Rethink the best way to parse and load yaml config files
    ignore_fields = set(additional_fields).union(
        {
            "user_messages",
            "bot_messages",
            "instructions",
            "flows",
            "models",
            "prompts",
            "docs",
            "actions_server_url",
            "sensitive_data_detection",
            "embedding_search_provider",
            "import_paths",
            "hooks_server",
        }
    )

    for key in additional_config.keys() - ignore_fields - RailsConfig.model_fields.keys():
        _warn_unknown_config_key(key, RailsConfig.model_fields)

    # Reads all the other fields and merges them with the custom_data field
    merge_two_dicts(dest_config.get("custom_data", {}), additional_config, ignore_fields)


def _load_path(
    config_path: str,
) -> Tuple[dict, List[Tuple[str, str]]]:
    """Load a configuration object from the specified path.

    Args:
        config_path: The path from which to load.

    Returns:
        (raw_config, colang_files) The raw config object and the list of colang files.
    """
    raw_config = {}

    # The names of the colang files.
    colang_files = []

    if not os.path.exists(config_path):
        raise ValueError(f"Could not find config path: {config_path}")

    # the first .railsignore file found from cwd down to its subdirectories
    railsignore_path = utils.get_railsignore_path(config_path)
    ignore_patterns = utils.get_railsignore_patterns(railsignore_path) if railsignore_path else set()

    if os.path.isdir(config_path):
        for root, _, files in os.walk(config_path, followlinks=True):
            # Followlinks to traverse symlinks instead of ignoring them.

            for file in files:
                # Verify railsignore to skip loading
                ignored_by_railsignore = utils.is_ignored_by_railsignore(file, ignore_patterns)

                if ignored_by_railsignore:
                    continue

                # This is the raw configuration that will be loaded from the file.
                _raw_config = {}

                # Extract the full path for the file and compute relative path
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, config_path)

                # If it's a file in the `kb` folder we need to append it to the docs
                if rel_path.startswith("kb"):
                    _raw_config = {"docs": []}
                    if rel_path.endswith(".md"):
                        with open(full_path, encoding="utf-8") as f:
                            _raw_config["docs"].append({"format": "md", "content": f.read()})

                elif file.endswith(".yml") or file.endswith(".yaml"):
                    with open(full_path, "r", encoding="utf-8") as f:
                        _raw_config = yaml.safe_load(f.read())

                elif file.endswith(".co"):
                    colang_files.append((file, full_path))

                _join_config(raw_config, _raw_config, source=full_path)

    # If it's just a .co file, we append it as is to the config.
    elif config_path.endswith(".co"):
        colang_files.append((config_path, config_path))

    return raw_config, colang_files


def _load_imported_paths(raw_config: dict, colang_files: List[Tuple[str, str]]):
    """Load recursively all the imported path in the specified raw_config.

    Args:
        raw_config: The starting raw configuration (i.e., a dict)
        colang_files: The current set of colang files which will be extended as new
            configurations are loaded.
    """
    # We also keep a temporary array of all the paths that have been imported
    if "imported_paths" not in raw_config:
        raw_config["imported_paths"] = {}

    while len(raw_config["imported_paths"]) != len(raw_config["import_paths"]):
        for import_path in raw_config["import_paths"]:
            if import_path in raw_config["imported_paths"]:
                continue

            log.info(f"Loading imported path: {import_path}")

            # If the path does not exist, we try to resolve it using COLANGPATH
            actual_path = None
            if not os.path.exists(import_path):
                for root in colang_path_dirs:
                    if os.path.exists(os.path.join(root, import_path)):
                        actual_path = os.path.join(root, import_path)
                        break

                    # We also check if we can load it as a file.
                    if not import_path.endswith(".co") and os.path.exists(os.path.join(root, import_path + ".co")):
                        actual_path = os.path.join(root, import_path + ".co")
                        break
            else:
                actual_path = import_path

            if actual_path is None:
                formated_import_path = import_path.replace("/", ".")
                raise ValueError(
                    f"Import path '{formated_import_path}' could not be resolved.",
                )

            _raw_config, _colang_files = _load_path(actual_path)

            # Join them.
            _join_config(raw_config, _raw_config, source=actual_path)
            colang_files.extend(_colang_files)

            # And mark the path as imported.
            raw_config["imported_paths"][import_path] = actual_path


def _parse_colang_files_recursively(
    raw_config: dict,
    colang_files: List[Tuple[str, str]],
    parsed_colang_files: List[dict],
):
    """Helper function to parse all the Colang files.

    If there are imports, they will be imported recursively
    """
    from nemoguardrails.colang import parse_colang_file
    from nemoguardrails.colang.v2_x.lang.utils import format_colang_parsing_error_message
    from nemoguardrails.colang.v2_x.runtime.errors import ColangParsingError

    colang_version = raw_config.get("colang_version", "1.0")
    _rails_parsed_config = None

    # We start parsing the colang files one by one, and if we have
    # new import paths, we continue to update
    while len(parsed_colang_files) != len(colang_files):
        current_file, current_path = colang_files[len(parsed_colang_files)]

        with open(current_path, "r", encoding="utf-8") as f:
            content = f.read()
            try:
                _parsed_config = parse_colang_file(current_file, content=content, version=colang_version)
            except ValueError as e:
                raise ColangParsingError(f"Unsupported colang version {colang_version} for file: {current_path}") from e
            except Exception as e:
                raise ColangParsingError(
                    f"Error while parsing Colang file: {current_path}\n"
                    + format_colang_parsing_error_message(e, content)
                ) from e

            # We join only the "import_paths" field in the config for now
            _join_config(
                raw_config,
                {"import_paths": _parsed_config.get("import_paths", [])},
            )

            parsed_colang_files.append(_parsed_config)

        # If there are any new imports, we load them
        if raw_config.get("import_paths"):
            _load_imported_paths(raw_config, colang_files)

    if colang_version == "2.x" and _has_input_output_config_rails(raw_config):
        rails_flows = _get_rails_flows(raw_config)
        flow_definitions = "\n".join(_generate_rails_flows(rails_flows))

        current_file = "INTRINSIC_FLOW_GENERATION"

        _rails_parsed_config = parse_colang_file(current_file, content=flow_definitions, version=colang_version)

    if _rails_parsed_config:
        parsed_colang_files.append(_rails_parsed_config)
    # To allow overriding of elements from imported paths, we need to merge the
    # parsed data in reverse order.
    for file_parsed_data in reversed(parsed_colang_files):
        _join_config(raw_config, file_parsed_data)


class RailsConfig(BaseModel):
    """Configuration object for the models and the rails.

    TODO: add typed config for user_messages, bot_messages, and flows.
    """

    models: List[Model] = Field(description="The list of models used by the rails configuration.")

    user_messages: Dict[str, List[str]] = Field(
        default_factory=dict,
        description="The list of user messages that should be used for the rails.",
    )

    bot_messages: Dict[str, List[str]] = Field(
        default_factory=dict,
        description="The list of bot messages that should be used for the rails.",
    )

    flows: List[Union[Dict, Any]] = Field(
        default_factory=list,
        description="The list of flows that should be used for the rails.",
    )

    instructions: Optional[List[Instruction]] = Field(
        default=[Instruction.model_validate(obj) for obj in _default_config["instructions"]],
        description="List of instructions in natural language that the LLM should use.",
    )

    docs: Optional[List[Document]] = Field(
        default=None,
        description="List of documents that should be used for question answering.",
    )

    actions_server_url: Optional[str] = Field(
        default=None,
        description="The URL of the actions server that should be used for the rails.",
    )  # consider as conflict

    sample_conversation: Optional[str] = Field(
        default=_default_config["sample_conversation"],
        description="The sample conversation that should be used inside the prompts.",
    )

    prompts: Optional[List[TaskPrompt]] = Field(
        default=None,
        description="The prompts that should be used for the various LLM tasks.",
    )

    prompting_mode: Optional[str] = Field(
        default=_default_config["prompting_mode"],
        description="Allows choosing between different prompting strategies.",
    )

    config_path: Optional[str] = Field(default=None, description="The path from which the configuration was loaded.")

    import_paths: Optional[List[str]] = Field(
        default_factory=list,
        description="A list of additional paths from which configuration elements (colang flows, .yml files, actions)"
        " should be loaded.",
    )
    imported_paths: Optional[Dict[str, str]] = Field(
        default_factory=dict,
        description="The mapping between the imported paths and the actual full path to which they were resolved.",
    )

    # Some tasks need to be as deterministic as possible. The lowest possible temperature
    # will be used for those tasks. Models like dolly don't allow for a temperature of 0.0,
    # for example, in which case a custom one can be set.
    lowest_temperature: Optional[float] = Field(
        default=0.001,
        description="The lowest temperature that should be used for the LLM.",
    )

    # This should only be enabled for highly capable LLMs that reliably follow the multi-line output format.
    enable_multi_step_generation: Optional[bool] = Field(
        default=False,
        description="Whether to enable multi-step generation for the LLM.",
    )

    colang_version: str = Field(default="1.0", description="The Colang version to use.")

    custom_data: Dict = Field(
        default_factory=dict,
        description="Any custom configuration data that might be needed.",
    )

    knowledge_base: KnowledgeBaseConfig = Field(
        default_factory=KnowledgeBaseConfig,
        description="Configuration for the built-in knowledge base support.",
    )

    core: CoreConfig = Field(
        default_factory=CoreConfig,
        description="Configuration for core internal mechanics.",
    )

    rails: Rails = Field(
        default_factory=Rails,
        description="Configuration for the various rails (input, output, etc.).",
    )

    hooks_server: HooksServerConfig = Field(
        default_factory=HooksServerConfig,
        description="The tool policy of `nemoguardrails hooks-server`, which only that server reads.",
    )

    streaming: bool = Field(
        default=False,
        deprecated="The 'streaming' field is no longer required. Use stream_async() method directly instead. This field will be removed in a future version.",
        description="DEPRECATED: Use stream_async() method instead. This field is ignored.",
    )

    enable_rails_exceptions: bool = Field(
        default=False,
        description="If set, the pre-defined guardrails raise exceptions instead of returning pre-defined messages.",
    )

    passthrough: Optional[bool] = Field(
        default=None,
        description="Weather the original prompt should pass through the guardrails configuration as is. "
        "This means it will not be altered in any way. ",
    )

    event_source_uid: str = Field(
        default="NeMoGuardrails-Colang-2.x",
        description="The source ID of events sent by the Colang Runtime. Useful to identify the component that has sent an event.",
    )

    tracing: TracingConfig = Field(
        default_factory=TracingConfig,
        description="Configuration for tracing.",
    )

    metrics: MetricsConfig = Field(
        default_factory=MetricsConfig,
        description="Configuration for OTEL metrics emission (independent of tracing).",
    )

    @model_validator(mode="wrap")
    @classmethod
    def warn_unknown_keys(cls, values: Any, handler: ModelWrapValidatorHandler["RailsConfig"]) -> "RailsConfig":
        config = handler(values)
        if isinstance(values, dict):
            _warn_unknown_config_keys(values, config)
        return config

    @model_validator(mode="before")
    @classmethod
    def check_model_exists_for_input_rails(cls, values):
        """Make sure we have a model for each input rail where one is provided using $model=<model_type>"""
        rails = values.get("rails", {})
        input_flows = rails.get("input", {}).get("flows", [])

        # If no flows have a model, early-out
        input_flows_without_model = [_get_flow_model(flow) is None for flow in input_flows]
        if all(input_flows_without_model):
            return values

        models = values.get("models", []) or []
        model_types = {model.type if isinstance(model, Model) else model["type"] for model in models}

        for flow in input_flows:
            flow_model = _get_flow_model(flow)
            if not flow_model:
                continue
            if flow_model not in model_types:
                flow_id = _normalize_flow_id(flow)
                available_types = ", ".join(f"'{str(t)}'" for t in sorted(model_types)) if model_types else "none"
                raise InvalidRailsConfigurationError(
                    f"Input flow '{flow_id}' references model type '{flow_model}' that is not defined in the configuration. Detected model types: {available_types}."
                )
        return values

    @model_validator(mode="before")
    @classmethod
    def check_model_exists_for_output_rails(cls, values):
        """Make sure we have a model for each output rail where one is provided using $model=<model_type>"""
        rails = values.get("rails", {})
        output_flows = rails.get("output", {}).get("flows", [])

        # If no flows have a model, early-out
        output_flows_without_model = [_get_flow_model(flow) is None for flow in output_flows]
        if all(output_flows_without_model):
            return values

        models = values.get("models", []) or []
        model_types = {model.type if isinstance(model, Model) else model["type"] for model in models}

        for flow in output_flows:
            flow_model = _get_flow_model(flow)
            if not flow_model:
                continue
            if flow_model not in model_types:
                flow_id = _normalize_flow_id(flow)
                available_types = ", ".join(f"'{str(t)}'" for t in sorted(model_types)) if model_types else "none"
                raise InvalidRailsConfigurationError(
                    f"Output flow '{flow_id}' references model type '{flow_model}' that is not defined in the configuration. Detected model types: {available_types}."
                )
        return values

    # An "after" validator, unlike its input/output twins, reads the typed `rails` fields,
    # so it also covers configs that still use the deprecated `tool_output`/`tool_input` keys.
    @model_validator(mode="after")
    def check_model_exists_for_tool_rails(self) -> "RailsConfig":
        """Make sure we have every model a tool rail's manifest binds, such as the judge named by `$model=`"""
        from nemoguardrails.manifests import RailDirection, default_rail_catalog, parse_configured_surface

        tool_rail_flows = list(_tool_rail_flows(self.rails))
        if not tool_rail_flows:
            return self

        model_types = {model.type for model in self.models}
        surfaces = default_rail_catalog().surfaces()
        for tool_rail_flow in tool_rail_flows:
            try:
                name, params = parse_configured_surface(tool_rail_flow.flow)
            except ValueError:
                # A malformed flow reference isn't a model check's to report; the engine
                # rejects it as an invalid flow reference when it compiles the rail.
                continue
            surface = surfaces.get((RailDirection(tool_rail_flow.direction), name))
            # An unknown flow is a custom or Colang-defined rail, which declares no model bindings here.
            if surface is None:
                continue
            for model_type in _bound_model_types(surface, params):
                if model_type in model_types:
                    continue
                tool_clause = f" for tool '{tool_rail_flow.tool_name}'" if tool_rail_flow.tool_name is not None else ""
                available_types = ", ".join(f"'{str(t)}'" for t in sorted(model_types)) if model_types else "none"
                raise InvalidRailsConfigurationError(
                    f"{tool_rail_flow.section} flow '{name}'{tool_clause} references model type '{model_type}' that is not defined in the configuration. Detected model types: {available_types}."
                )
        return self

    @model_validator(mode="before")
    @classmethod
    def check_prompt_exist_for_self_check_rails(cls, values):
        rails = values.get("rails", {})
        prompts = values.get("prompts", []) or []

        enabled_input_rails = rails.get("input", {}).get("flows", [])
        enabled_output_rails = rails.get("output", {}).get("flows", [])
        provided_task_prompts = [prompt.task if hasattr(prompt, "task") else prompt.get("task") for prompt in prompts]

        # Input moderation prompt verification
        _validate_self_check_rail_prompts(
            enabled_input_rails, provided_task_prompts, "self check input", "self_check_input"
        )
        if "llama guard check input" in enabled_input_rails and "llama_guard_check_input" not in provided_task_prompts:
            raise InvalidRailsConfigurationError(
                "Missing a `llama_guard_check_input` prompt template, which is required for the `llama guard check input` rail."
            )

        # Only content-safety and topic-safety include a $model reference in the rail flow text
        # Need to match rails with flow_id (excluding $model reference) and match prompts
        # on the full flow_id (including $model reference)
        _validate_rail_prompts(enabled_input_rails, provided_task_prompts, "content safety check input")
        _validate_rail_prompts(enabled_input_rails, provided_task_prompts, "topic safety check input")

        # Output moderation prompt verification
        _validate_self_check_rail_prompts(
            enabled_output_rails, provided_task_prompts, "self check output", "self_check_output"
        )
        if (
            "llama guard check output" in enabled_output_rails
            and "llama_guard_check_output" not in provided_task_prompts
        ):
            raise InvalidRailsConfigurationError(
                "Missing a `llama_guard_check_output` prompt template, which is required for the `llama guard check output` rail."
            )
        if (
            "patronus lynx check output hallucination" in enabled_output_rails
            and "patronus_lynx_check_output_hallucination" not in provided_task_prompts
        ):
            raise InvalidRailsConfigurationError(
                "Missing a `patronus_lynx_check_output_hallucination` prompt template, which is required for the `patronus lynx check output hallucination` rail."
            )

        if "self check facts" in enabled_output_rails and "self_check_facts" not in provided_task_prompts:
            raise InvalidRailsConfigurationError(
                "Missing a `self_check_facts` prompt template, which is required for the `self check facts` rail."
            )

        # Only content-safety and topic-safety include a $model reference in the rail flow text
        # Need to match rails with flow_id (excluding $model reference) and match prompts
        # on the full flow_id (including $model reference)
        _validate_rail_prompts(enabled_output_rails, provided_task_prompts, "content safety check output")

        return values

    @model_validator(mode="before")
    @classmethod
    def check_output_parser_exists(cls, values):
        tasks_requiring_output_parser = [
            "self_check_input",
            "self_check_facts",
            "self_check_output",
            # "content_safety_check input $model",
            # "content_safety_check output $model",
        ]
        prompts = values.get("prompts") or []
        for prompt in prompts:
            task = prompt.task if hasattr(prompt, "task") else prompt.get("task")
            output_parser = prompt.output_parser if hasattr(prompt, "output_parser") else prompt.get("output_parser")

            if any(task.startswith(task_prefix) for task_prefix in tasks_requiring_output_parser) and not output_parser:
                log.info(
                    f"Deprecation Warning: Output parser is not registered for the task. "
                    f"The correct way is to register the 'output_parser' in the prompts.yml for '{task}' task. "
                    "It uses 'is_content safe' as the default output parser."
                    "This behavior will be deprecated in future versions."
                )
        return values

    @model_validator(mode="before")
    @classmethod
    def check_streaming_can_apply_output_rewrites(cls, values):
        """Reject configs whose output rails transform response with `stream_first` == True"""
        from nemoguardrails.manifests import RailDirection, default_rail_catalog, parse_configured_surface

        rails = values.get("rails") or {}
        output = rails.get("output") or {}
        streaming = output.get("streaming") or {}
        if not streaming.get("enabled", False):
            return values

        surfaces = default_rail_catalog().surfaces()
        rewriting = []
        for flow in output.get("flows") or []:
            try:
                name, _ = parse_configured_surface(flow)
            except ValueError:
                continue
            surface = surfaces.get((RailDirection.OUTPUT, name))
            # An unknown flow is a custom or Colang-defined rail, which declares no target here.
            if surface is not None and surface.transform_target is not None:
                rewriting.append(flow)
        if not rewriting:
            return values

        defaults = OutputRailsStreamingConfig()
        stream_first = streaming.get("stream_first", defaults.stream_first)
        context_size = streaming.get("context_size", defaults.context_size)
        offending = [
            setting
            for setting, unusable in (
                ("stream_first: True", stream_first),
                (f"context_size: {context_size}", context_size),
            )
            if unusable
        ]
        if not offending:
            return values

        raise InvalidRailsConfigurationError(
            f"Output rails {rewriting} rewrite the response, which streaming cannot apply with "
            f"{' and '.join(offending)}: set rails.output.streaming.stream_first to False and "
            f"context_size to 0, or remove the rewriting rails from a streaming configuration."
        )

    @model_validator(mode="before")
    @classmethod
    def check_jailbreak_detection_config(cls, values):
        """Validate jailbreak detection configuration against enabled flows."""
        rails = values.get("rails") or {}
        config_data = rails.get("config") or {}
        input_flows = (rails.get("input") or {}).get("flows") or []

        jailbreak_config = config_data.get("jailbreak_detection") or {}
        has_model_flow = JAILBREAK_FLOW_MODEL in input_flows
        has_heuristics_flow = JAILBREAK_FLOW_HEURISTICS in input_flows
        has_any_jailbreak_flow = has_model_flow or has_heuristics_flow

        # Case A: Config present but no flow references it
        if jailbreak_config and not has_any_jailbreak_flow:
            log.warning(
                "Jailbreak detection configuration is present under "
                "rails.config.jailbreak_detection but no jailbreak detection flow "
                "is enabled. To use jailbreak detection, add 'jailbreak detection model' "
                "or 'jailbreak detection heuristics' to rails.input.flows."
            )

        # Case B: "jailbreak detection model" flow is enabled
        if has_model_flow:
            try:
                importlib.metadata.distribution("tokenizers")
            except importlib.metadata.PackageNotFoundError as exc:
                raise InvalidRailsConfigurationError(
                    "The 'jailbreak detection model' rail requires tokenizers for all backends. "
                    "Install it with: pip install tokenizers"
                ) from exc

            nim_base_url = jailbreak_config.get("nim_base_url")
            nim_url = jailbreak_config.get("nim_url")  # deprecated, migrated later
            server_endpoint = jailbreak_config.get("server_endpoint")
            nim_server_endpoint = jailbreak_config.get("nim_server_endpoint", "classify")

            if nim_base_url or nim_url:
                if not nim_server_endpoint:
                    raise InvalidRailsConfigurationError(
                        "nim_base_url is set for jailbreak detection model but "
                        "nim_server_endpoint is empty. Both must be configured "
                        "when using NIM-based jailbreak detection."
                    )
            elif not server_endpoint:
                log.warning(
                    "No endpoint configured for jailbreak detection model. "
                    "Will fall back to local in-process detection, which is "
                    "not recommended for production."
                )

        # Case C: "jailbreak detection heuristics" flow is enabled
        if has_heuristics_flow:
            server_endpoint = jailbreak_config.get("server_endpoint")
            if not server_endpoint:
                log.warning(
                    "No server_endpoint configured for jailbreak detection heuristics. "
                    "Will fall back to local in-process detection, which is "
                    "not recommended for production."
                )

        return values

    @model_validator(mode="before")
    @classmethod
    def fill_in_default_values_for_v2_x(cls, values):
        instructions = values.get("instructions", {})
        sample_conversation = values.get("sample_conversation")
        colang_version = values.get("colang_version", "1.0")

        if colang_version == "2.x":
            if not instructions:
                values["instructions"] = _default_config_v2["instructions"]

            if not sample_conversation:
                values["sample_conversation"] = _default_config_v2["sample_conversation"]

        return values

    @field_validator("models")
    @classmethod
    def validate_models_api_key_env_var(cls, models):
        """Model API Key Env var must be set to make LLM calls"""
        api_keys = [m.api_key_env_var for m in models]
        for api_key in api_keys:
            if api_key and not os.environ.get(api_key):
                raise InvalidRailsConfigurationError(f"Model API Key environment variable '{api_key}' not set.")
        return models

    raw_llm_call_action: Optional[str] = Field(
        default="raw llm call",
        description="The name of the action that would execute the original raw LLM call. ",
    )

    @classmethod
    def from_path(
        cls,
        config_path: str,
    ):
        """Loads a configuration from a given path.

        Supports loading a from a single file, or from a directory.
        """
        if "," in config_path or config_path != config_path.strip():
            raise ValueError(
                f"Invalid config path {config_path!r}. Paths cannot contain commas or begin or end with whitespace."
            )

        # If the config path is a file, we load the YAML content.
        # Otherwise, if it's a folder, we iterate through all files.
        if os.path.isfile(config_path) and config_path.endswith((".yaml", ".yml")):
            with open(config_path) as f:
                raw_config = yaml.safe_load(f.read())

        elif os.path.isdir(config_path):
            raw_config, colang_files = _load_path(config_path)

            # If we have import paths, we also need to load them.
            if raw_config.get("import_paths"):
                _load_imported_paths(raw_config, colang_files)

            # Parse the colang files after we know the colang version
            _parse_colang_files_recursively(raw_config, colang_files, parsed_colang_files=[])

        else:
            raise ValueError(f"Invalid config path {config_path}.")

        # If there are no instructions, we use the default ones.
        if len(raw_config.get("instructions", [])) == 0:
            raw_config["instructions"] = _default_config["instructions"]

        raw_config["config_path"] = config_path

        return cls.parse_object(raw_config)

    @classmethod
    def from_content(
        cls,
        colang_content: Optional[str] = None,
        yaml_content: Optional[str] = None,
        config: Optional[dict] = None,
    ):
        """Loads a configuration from the provided colang/YAML content/config dict."""
        from nemoguardrails.colang import parse_colang_file

        raw_config = {}

        if config:
            _join_config(raw_config, config)

        if yaml_content:
            _join_config(raw_config, yaml.safe_load(yaml_content))

        # Parse the colang files after we know the colang version
        colang_version = raw_config.get("colang_version", "1.0")

        # We start parsing the colang files one by one, and if we have
        # new import paths, we continue to update
        colang_files = []
        parsed_colang_files = []

        # First, we parse the starting content.
        if colang_content:
            colang_files.append(("main.co", "main.co"))

            _parsed_config = parse_colang_file(
                "main.co",
                content=colang_content,
                version=colang_version,
            )

            # We join only the "import_paths" field in the config for now
            _join_config(
                raw_config,
                {"import_paths": _parsed_config.get("import_paths", [])},
            )

            parsed_colang_files.append(_parsed_config)

        # Load any new colang files potentially coming from imports
        if raw_config.get("import_paths"):
            _load_imported_paths(raw_config, colang_files)

        # Next, we parse any additional files recursively
        _parse_colang_files_recursively(raw_config, colang_files, parsed_colang_files)

        # If there are no instructions, we use the default ones.
        if len(raw_config.get("instructions", [])) == 0:
            raw_config["instructions"] = _default_config["instructions"]

        return cls.parse_object(raw_config)

    @classmethod
    def parse_object(cls, obj):
        """Parses a configuration object from a given dictionary."""
        from nemoguardrails.colang import parse_flow_elements

        # If we have flows, we need to process them further from CoYML to CIL, but only for
        # version 1.0.

        if obj.get("colang_version", "1.0") == "1.0":
            for flow_data in obj.get("flows", []):
                # If the first element in the flow does not have a "_type", we need to convert
                if flow_data.get("elements") and not flow_data["elements"][0].get("_type"):
                    flow_data["elements"] = parse_flow_elements(flow_data["elements"])

        return cls.model_validate(obj)

    def __add__(self, other):
        """Adds two RailsConfig objects."""
        return _join_rails_configs(self, other)


def _join_dict(dict1, dict2):
    """
    Joins two dictionaries recursively.
    - If values are dictionaries, it applies _join_dict recursively.
    - If values are lists, it concatenates them, ensuring unique elements.
    - For other types, values from dict2 overwrite dict1.
    """
    result = dict(dict1)  # Create a copy of dict1 to avoid modifying the original

    for key, value in dict2.items():
        # If key is in both dictionaries and both values are dictionaries, apply _join_dict recursively
        if key in dict1 and isinstance(dict1[key], dict) and isinstance(value, dict):
            result[key] = _join_dict(dict1[key], value)
        # If key is in both dictionaries and both values are lists, concatenate unique elements
        elif key in dict1 and isinstance(dict1[key], list) and isinstance(value, list):
            # Since we want values from dict2 to take precedence, we concatenate dict2 first
            result[key] = _unique_list_concat(value, dict1[key])
        # Otherwise, simply overwrite the value from dict2
        else:
            result[key] = value

    return result


def _unique_list_concat(list1, list2):
    """
    Concatenates two lists ensuring all elements are unique.
    Handles unhashable types like dictionaries.
    """
    result = list(list1)
    for item in list2:
        if item not in result:
            result.append(item)
    return result


def _join_rails_configs(base_rails_config: RailsConfig, updated_rails_config: RailsConfig):
    """Helper to join two rails configuration."""

    config_old_types = {}
    for model_old in base_rails_config.models:
        config_old_types[model_old.type] = model_old

    for model_new in updated_rails_config.models:
        if model_new.type in config_old_types:
            if model_new.engine != config_old_types[model_new.type].engine:
                raise ValueError("Both config files should have the same engine for the same model type")
            if model_new.model != config_old_types[model_new.type].model:
                raise ValueError("Both config files should have the same model for the same model type")

    if base_rails_config.actions_server_url != updated_rails_config.actions_server_url:
        raise ValueError("Both config files should have the same actions_server_url")

    # A section can't be told apart from an unset one after validation, so "set" means "not the default".
    hooks_servers = [
        config.hooks_server
        for config in (base_rails_config, updated_rails_config)
        if config.hooks_server != HooksServerConfig()
    ]
    if len(hooks_servers) > 1:
        raise ValueError("Both configs set a hooks_server section, which only one of them may set")

    combined_rails_config_dict = _join_dict(base_rails_config.model_dump(), updated_rails_config.model_dump())
    if hooks_servers:
        # Every dump carries the section's defaults, which the join would mix into the set section. Only the fields
        # the section set are kept, so the hooks server can still tell an unset allow_unlisted_tools from a choice.
        combined_rails_config_dict["hooks_server"] = hooks_servers[0].model_dump(exclude_unset=True)
    # filter out empty strings to avoid leading/trailing commas
    config_paths = [
        base_rails_config.model_dump()["config_path"] or "",
        updated_rails_config.model_dump()["config_path"] or "",
    ]
    combined_rails_config_dict["config_path"] = ",".join(filter(None, config_paths))
    combined_rails_config = RailsConfig.parse_object(combined_rails_config_dict)
    return combined_rails_config


def _has_input_output_config_rails(raw_config):
    """Checks if the raw configuration has input/output rails configured."""

    has_input_rails = len(raw_config.get("rails", {}).get("input", {}).get("flows", [])) > 0
    has_output_rails = len(raw_config.get("rails", {}).get("output", {}).get("flows", [])) > 0
    return has_input_rails or has_output_rails


def _get_rails_flows(raw_config):
    """Extracts the list of flows from the raw_config dictionary.

    Args:
        raw_config (dict): The raw configuration dictionary.

    Returns:
        list: The list of flows.
    """
    from collections import defaultdict

    flows = defaultdict(list)

    for key in raw_config["rails"]:
        if "flows" in raw_config["rails"][key]:
            flows[key].extend(raw_config["rails"][key]["flows"])
    return flows


def _generate_rails_flows(flows):
    """Generates flow definitions from the list of flows.
    Args:
        flows (dict): The dictionary of flows.
    Returns:
        str: The flow definitions.
    """
    _MAPPING = {
        "input": "flow input rails $input_text",
        "output": "flow output rails $output_text",
    }

    _GUARDRAILS_IMPORT = "import guardrails"
    _LIBRARY_IMPORT = "import nemoguardrails.library"

    flow_definitions = []
    _INDENT = "    "  # 4 spaces for indentation
    _NEWLINE = "\n"

    for key, value in flows.items():
        flow_definitions.append(_MAPPING[key] + _NEWLINE)
        for v in value:
            flow_definitions.append(_INDENT + v + _NEWLINE)
        flow_definitions.append(_NEWLINE)  # Add an empty line after each flow

    if flow_definitions:
        flow_definitions.insert(0, _GUARDRAILS_IMPORT + _NEWLINE)
        flow_definitions.insert(1, _LIBRARY_IMPORT + _NEWLINE * 2)

    return flow_definitions


MODEL_PREFIX = "$model="


def _get_flow_name(flow_text) -> Optional[str]:
    """Helper to return a model name from a flow definition"""
    return _normalize_flow_id(flow_text)


def _get_flow_model(flow_text) -> Optional[str]:
    """Helper to return a model name from a flow definition"""
    if MODEL_PREFIX not in flow_text:
        return None
    from nemoguardrails.manifests import parse_configured_surface

    _, parameters = parse_configured_surface(flow_text)
    return parameters.get("model")


@dataclass(frozen=True)
class _ToolRailFlow:
    """A configured tool rail flow, with its section, its direction and, for a per-tool flow, its tool."""

    section: str
    direction: str
    tool_name: Optional[str]
    flow: str


def _tool_rail_flows(rails: Rails) -> Iterator[_ToolRailFlow]:
    """Yield each tool rail flow, global flows before per-tool ones."""
    # Read the canonical fields: the deprecated `tool_output`/`tool_input` attributes warn when read.
    sections = (("Tool call", "tool_call", rails.tool_call), ("Tool result", "tool_result", rails.tool_result))
    for section, direction, tool_rails in sections:
        for flow in tool_rails.flows:
            yield _ToolRailFlow(section=section, direction=direction, tool_name=None, flow=flow)
        for tool_name, flows in tool_rails.per_tool.items():
            for flow in flows:
                yield _ToolRailFlow(section=section, direction=direction, tool_name=tool_name, flow=flow)


def _bound_model_types(surface: "RailSurface", params: Dict[str, str]) -> Iterator[str]:
    """Yield the model types *surface* binds for a flow's *params*: baked-in literals and model `$params` it sets."""
    for binding in surface.bindings:
        if binding.resource != "model":
            continue
        if binding.kind == "literal":
            yield str(binding.value)
        elif binding.key in params:
            yield params[binding.key]


def _validate_self_check_rail_prompts(
    rails: list[str], prompts: list[Any], validation_rail: str, default_task: str
) -> None:
    """Ensure every enabled self-check rail has a prompt for its resolved task.

    A self-check rail may select a custom task via `$variant=...`; the task falls
    back to `default_task` when omitted. Custom prompts are scoped under the
    default task name.
    """
    for rail in rails:
        if _normalize_flow_id(rail) != validation_rail:
            continue
        task = _get_flow_params(rail).get("variant") or default_task
        prompt_task = get_self_check_prompt_task(task, default_task, prompts)
        if prompt_task not in prompts:
            raise InvalidRailsConfigurationError(
                f"Missing a `{prompt_task}` prompt template, which is required for the `{rail}` rail."
            )


def _validate_rail_prompts(rails: list[str], prompts: list[Any], validation_rail: str) -> None:
    for rail in rails:
        flow_id = _normalize_flow_id(rail)
        flow_model = _get_flow_model(rail)
        if flow_id == validation_rail:
            prompt_flow_id = flow_id.replace(" ", "_")
            expected_prompt = f"{prompt_flow_id} $model={flow_model}"
            if expected_prompt not in prompts:
                raise InvalidRailsConfigurationError(
                    f"Missing a `{expected_prompt}` prompt template, which is required for the `{validation_rail}` rail."
                )


validate_no_config_export_shadowing(globals().keys())
__all__ = sorted({name for name in globals() if not name.startswith("_")} | set(config_exported_names()))  # noqa: PLE0605
