# SPDX-FileCopyrightText: Copyright (c) 2023-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import os
from collections.abc import Mapping
from typing import Any, Optional

from pydantic import BaseModel
from pydantic_core import to_json
from typing_extensions import Literal, cast

from nemoguardrails.actions import action
from nemoguardrails.actions.rail_outcome import RailOutcome, TransformTarget
from nemoguardrails.http import HTTPClient, http_call
from nemoguardrails.rails.llm.config import PangeaRailConfig, RailsConfig

log = logging.getLogger(__name__)


class Message(BaseModel):
    role: str
    content: str


class TextGuardResult(BaseModel):
    prompt_messages: Optional[list[Message]] = None
    """Updated structured prompt, if applicable."""

    blocked: Optional[bool] = None
    """Whether or not the prompt triggered a block detection."""

    transformed: Optional[bool] = None
    """Whether or not the original input was transformed."""

    # Additions.
    bot_message: Optional[str] = None
    user_message: Optional[str] = None


class TextGuardResponse(BaseModel):
    result: TextGuardResult


def get_pangea_config(config: RailsConfig) -> PangeaRailConfig:
    if not hasattr(config.rails.config, "pangea") or config.rails.config.pangea is None:
        return PangeaRailConfig()

    return cast(PangeaRailConfig, config.rails.config.pangea)


def _pangea_outcome(result: TextGuardResult, mode: Literal["input", "output"]) -> RailOutcome:
    metadata = {
        "blocked": bool(result.blocked),
        "transformed": bool(result.transformed),
        "prompt_messages": result.prompt_messages,
        "user_message": result.user_message,
        "bot_message": result.bot_message,
    }
    if result.blocked:
        return RailOutcome.block(metadata=metadata)
    if result.transformed:
        target = TransformTarget.USER_MESSAGE if mode == "input" else TransformTarget.BOT_MESSAGE
        text = result.user_message if mode == "input" else result.bot_message
        return RailOutcome.transform(
            [(target, text or "")],
            metadata=metadata,
        )
    return RailOutcome.allow(metadata=metadata)


@action(is_system_action=True)
async def pangea_ai_guard(
    mode: Literal["input", "output"],
    config: RailsConfig,
    context: Mapping[str, Any] = {},
    user_message: Optional[str] = None,
    bot_message: Optional[str] = None,
    http_client: Optional[HTTPClient] = None,
) -> RailOutcome:
    """Evaluate input or output content with Pangea AI Guard.

    Provider results may allow, block, or transform the selected message.
    Failures while calling or validating the provider response are logged and
    fail open with the original content.

    Args:
        mode: Whether to evaluate input or output content.
        config: Rails configuration containing the Pangea settings.
        context: Runtime context used to resolve messages.
        user_message: Optional user message overriding the context value.
        bot_message: Optional bot message overriding the context value.
        http_client: Optional caller-owned HTTP client.

    Returns:
        The provider decision, or an allow outcome after a provider failure.

    Raises:
        ValueError: If the API token or content is missing.
    """
    pangea_base_url_template = os.getenv("PANGEA_BASE_URL_TEMPLATE", "https://{SERVICE_NAME}.aws.us.pangea.cloud")
    pangea_api_token = os.getenv("PANGEA_API_TOKEN")

    if not pangea_api_token:
        raise ValueError("PANGEA_API_TOKEN environment variable is not set.")

    pangea_config = get_pangea_config(config)

    user_message = user_message or context.get("user_message")
    bot_message = bot_message or context.get("bot_message")

    if not any([user_message, bot_message]):
        raise ValueError("Either user_message or bot_message must be provided.")

    messages: list[Message] = []
    if config.instructions:
        messages.extend([Message(role="system", content=instruction.content) for instruction in config.instructions])
    if user_message:
        messages.append(Message(role="user", content=user_message))
    if mode == "output" and bot_message:
        messages.append(Message(role="assistant", content=bot_message))

    recipe = (
        pangea_config.input.recipe
        if mode == "input" and pangea_config.input
        else (pangea_config.output.recipe if mode == "output" and pangea_config.output else None)
    )

    data = {"messages": messages, "recipe": recipe}
    data = {k: v for k, v in data.items() if v is not None}
    endpoint = pangea_base_url_template.format(SERVICE_NAME="ai-guard").rstrip("/") + "/v1/text/guard"
    try:
        response = await http_call(
            http_client,
            "POST",
            endpoint,
            content=to_json(data),
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {pangea_api_token}",
                "Content-Type": "application/json",
                "User-Agent": "NeMo Guardrails (https://github.com/NVIDIA-NeMo/Guardrails)",
            },
            raise_for_status=False,
        )
        response.raise_for_status()
        text_guard_response = TextGuardResponse(**response.json())
    except Exception as e:
        log.error("Error calling Pangea AI Guard API: %s", e)
        return _pangea_outcome(
            TextGuardResult(
                prompt_messages=messages,
                blocked=False,
                transformed=False,
                bot_message=bot_message,
                user_message=user_message,
            ),
            mode,
        )

    result = text_guard_response.result
    prompt_messages = result.prompt_messages or []

    result.bot_message = next((m.content for m in prompt_messages if m.role == "assistant"), bot_message)
    result.user_message = next((m.content for m in prompt_messages if m.role == "user"), user_message)

    return _pangea_outcome(result, mode)
