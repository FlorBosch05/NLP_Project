# SPDX-FileCopyrightText: Copyright (c) 2023-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
from typing import Any, Dict, List, Optional

from nemoguardrails.actions.actions import action
from nemoguardrails.actions.rail_outcome import RailOutcome
from nemoguardrails.context import llm_call_info_var
from nemoguardrails.llm.cache import CacheInterface
from nemoguardrails.llm.cache.utils import (
    CacheEntry,
    create_normalized_cache_key,
    extract_llm_metadata_for_cache,
    extract_llm_stats_for_cache,
    get_from_cache_and_restore_stats,
)
from nemoguardrails.llm.call import llm_call
from nemoguardrails.llm.filters import to_chat_messages
from nemoguardrails.llm.taskmanager import LLMTaskManager
from nemoguardrails.logging.explain import LLMCallInfo
from nemoguardrails.types import LLMModel

log = logging.getLogger(__name__)

TOPIC_SAFETY_OUTPUT_RESTRICTION = (
    'If any of the above conditions are violated, please respond with "off-topic". '
    'Otherwise, respond with "on-topic". '
    'You must respond with "on-topic" or "off-topic".'
)
TOPIC_SAFETY_TEMPERATURE = 0.01


@action()
async def topic_safety_check_input(
    llms: Dict[str, LLMModel],
    llm_task_manager: LLMTaskManager,
    model_name: Optional[str] = None,
    context: Optional[dict] = None,
    user_message: Optional[str] = None,
    events: Optional[List[dict]] = None,
    model_caches: Optional[Dict[str, CacheInterface]] = None,
    **kwargs,
) -> RailOutcome:
    user_input = user_message or ""
    conversation_history: List[dict] = []

    if context is not None:
        if user_message is None:
            user_input = context.get("user_message", "")
        model_name = model_name or context.get("model", None)

    if events is not None:
        # convert InternalEvent objects to dictionary format for compatibility with to_chat_messages
        dict_events = []
        for event in events:
            if hasattr(event, "name") and hasattr(event, "arguments"):
                dict_event = {"type": event.name}
                dict_event.update(event.arguments)
                dict_events.append(dict_event)
            else:
                dict_events.append(event)

        conversation_history = to_chat_messages(dict_events)

    if model_name is None:
        error_msg = (
            "Model name is required for topic safety check, "
            "please provide it as an argument in the config.yml. "
            "e.g. topic safety check input $model=llama_topic_guard"
        )
        raise ValueError(error_msg)

    llm = llms.get(model_name, None)

    if llm is None:
        error_msg = (
            f"Model {model_name} not found in the list of available models for topic safety check. "
            "Please provide a valid model name."
        )
        raise ValueError(error_msg)

    task = f"topic_safety_check_input $model={model_name}"

    system_prompt = llm_task_manager.render_task_prompt(
        task=task,
    )

    system_prompt = system_prompt.strip()
    if not system_prompt.endswith(TOPIC_SAFETY_OUTPUT_RESTRICTION):
        system_prompt = f"{system_prompt}\n\n{TOPIC_SAFETY_OUTPUT_RESTRICTION}"

    stop = llm_task_manager.get_stop_tokens(task=task)
    max_tokens = llm_task_manager.get_max_tokens(task=task)

    llm_call_info_var.set(LLMCallInfo(task=task))

    messages = []
    messages.append({"type": "system", "content": system_prompt})
    messages.extend(conversation_history)
    messages.append({"type": "user", "content": user_input})

    cache = model_caches.get(model_name) if model_caches else None

    if cache:
        cache_key = create_normalized_cache_key(messages)
        cached_result = get_from_cache_and_restore_stats(cache, cache_key)
        if cached_result is not None:
            log.debug(f"Topic safety cache hit for model '{model_name}'")
            return cached_result

    llm_params: Dict[str, Any] = {"temperature": TOPIC_SAFETY_TEMPERATURE}
    if max_tokens:
        llm_params["max_tokens"] = max_tokens

    response = await llm_call(llm, messages, stop=stop, llm_params=llm_params)
    result = response.content

    if result.lower().strip() == "off-topic":
        on_topic = False
    else:
        on_topic = True

    final_result = RailOutcome.allow() if on_topic else RailOutcome.block()

    if cache:
        cache_key = create_normalized_cache_key(messages)
        cache_entry: CacheEntry = {
            "result": final_result,
            "llm_stats": extract_llm_stats_for_cache(),
            "llm_metadata": extract_llm_metadata_for_cache(),
        }
        cache.put(cache_key, cache_entry)
        log.debug(f"Topic safety result cached for model '{model_name}'")

    return final_result
