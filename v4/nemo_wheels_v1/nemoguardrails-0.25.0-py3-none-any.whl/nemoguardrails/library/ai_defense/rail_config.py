# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from nemoguardrails.manifests.config_schema import (
    Field,
    RailConfigBaseModel,
    RailConfigSpec,
    rail_field,
)


class AIDefenseRailConfig(RailConfigBaseModel):
    """Configuration data for the Cisco AI Defense API"""

    timeout: float = Field(
        default=30.0,
        gt=0,
        description="Timeout in seconds for API requests to AI Defense service",
    )

    fail_open: bool = Field(
        default=False,
        description="If True, allow content when AI Defense API call fails (fail open). If False, block content when API call fails (fail closed). Does not affect missing configuration validation.",
    )


def build_config_spec() -> RailConfigSpec:
    return RailConfigSpec(
        annotation=Optional[AIDefenseRailConfig],
        field_info=rail_field(
            default_factory=AIDefenseRailConfig,
            description="Configuration for Cisco AI Defense.",
        ),
        exports={"AIDefenseRailConfig": AIDefenseRailConfig},
    )
