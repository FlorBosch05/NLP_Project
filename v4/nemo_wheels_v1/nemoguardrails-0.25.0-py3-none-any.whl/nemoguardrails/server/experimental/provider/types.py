# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Define provider-neutral values shared by the guarded proxy pipeline."""

from dataclasses import dataclass
from enum import Enum
from typing import Any, Literal

JsonObject = dict[str, Any]


class UnknownContentFieldPolicy(str, Enum):
    """Control whether unreviewed fields may accompany guarded content."""

    ALLOW = "allow"
    FORBID = "forbid"


@dataclass(frozen=True, slots=True)
class GuardedMessage:
    """Represent one message inspected by input or output rails."""

    role: Literal["user", "assistant"]
    content: str

    def __post_init__(self) -> None:
        """Reject roles and content that the checker boundary does not define."""

        if self.role not in ("user", "assistant"):
            raise ValueError("A guarded message role must be 'user' or 'assistant'.")
        if not isinstance(self.content, str):
            raise TypeError("Guarded message content must be a string.")
