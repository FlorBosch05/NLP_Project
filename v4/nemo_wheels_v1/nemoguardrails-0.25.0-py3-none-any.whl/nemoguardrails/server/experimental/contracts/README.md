# Guard contracts

A guard contract describes a provider operation's guardrail boundary: which
content is inspected, which values are restricted, and which data remains under
provider authority. It makes that boundary reviewable without reading Python.

The Python projection models, bindings, and endpoint implementation are the
source of truth. A contract is a description of their policy, not server
configuration or a second policy to maintain by hand. Deployment configuration
selects the rails that inspect supported content.

This directory defines the experimental document format and an illustrative
example. Provider exports belong with their integrations; the format alone does
not implement an endpoint, an exporter, or runtime YAML loading.

## Document structure

Start with [minimal.guard.example.yaml](minimal.guard.example.yaml). It marks
request `prompt` and response `text` as guarded, leaves `model` opaque, and
constrains response `status` to `complete`. It is a format example, not the
output of a provider integration.

| Section | Describes |
| --- | --- |
| `version`, `operationId`, `profile` | Format revision, provider operation, and framework capability. |
| `request`, `response` | Request and buffered-response payload projections. |
| `stream` | Optional event payloads, classifications, and transport framing. |
| `excluded_stream_events` | Explicitly unsupported event schemas and the reasons for exclusion. |
| `integration.endpoint` | Endpoint metadata such as route, rejection codes, and implementation bindings. |

Payload projections use a subset of JSON Schema vocabulary: `type`,
`properties`, `required`, `items`, `oneOf`, constants, enums, and bounds.
Guard annotations use the `x-nemo-guardrails` key. Other `x-` extensions are
allowed, but every other key starting with `x-nemo` is reserved and rejected.

## Field policy

| Declaration | Meaning |
| --- | --- |
| `classification: guarded` | A text subject, or a container leading to it. |
| `subject` | Identifies text, its user/assistant role, and replacement eligibility. |
| `classification: constrained` | Restricts a value or shape without making it a rail subject. |
| `gate: disabled` | Marks a constrained, null-only field for an unsupported feature. |
| `classification: opaque` | Leaves the value under provider authority, without guardrail inspection. |
| `opaque_fields` | Legacy object-level inventory; canonical exports use opaque-classified properties. |
| `reason` | Explains a restriction: capability, provider integrity, or projection policy. |

Opaque does not mean safe or trusted. Its nested content is not independently
reviewed. Canonical exports declare each reviewed opaque name in `properties`.
A legacy `opaque_fields` inventory must not overlap declared properties or use
wildcards.
`extension: true` identifies a local compatibility field outside the pinned
provider schema, not an exemption from review.

An object's `required` list controls presence; nullability is separate. Disabled
fields can be omitted when optional, or supplied as null, but cannot enable the
feature. A `default` describes an internal default, not permission to insert
fields into the forwarded provider payload.

`replaceable` records text replacement eligibility. `replacement_blocked_by`
identifies metadata that can prevent replacement, with a `replacement_reason`.
The integration determines the blocking predicate and whether replacement
outcomes can be executed. Neither marking a subject nor marking it replaceable
enables a detector or a runtime capability.

## Object and stream metadata

`model` identifies the Python model; `source` identifies a provider schema
component. Canonical exports explicitly declare `unknown_fields: forbid` or
`unknown_fields: configurable` on every reviewed object. Both use
`additionalProperties: false` for default validation. Only trusted configuration
may select `ALLOW` on a configurable object; a contract-aware validator then
permits its unreviewed members. Closed objects remain closed under either policy.
Objects without the marker are closed. Generic JSON Schema validators
apply the default closure but do not implement trusted overrides. Reviewed opaque
names appear as properties classified `opaque`, so `additionalProperties` describes only unreviewed members.

Canonical exports also declare `reject_case_aliases: true` on every reviewed
object. A member not listed in `properties` is rejected when its Unicode
`casefold()` equals the fold of a listed name, even under trusted `ALLOW`.
This includes multi-character folds (`Straße` and `STRASSE`), the Kelvin sign
(`key` and `Key`), and long-s (`refusal` and `refuſal`). Exact listed names remain
valid, whitespace remains significant, and opaque values are not traversed.
Some providers match names case-insensitively, so runtimes and generators must
enforce this explicit guardrail annotation. Generic JSON Schema ignores it.
`additionalProperties` remains the ordinary schema-level object closure rule.
Provider-required opaque fields may be left to provider validation; a projection is not a full provider request validator.

Object `variant` metadata describes discriminator matching and selected-variant
cardinality. This is distinct from ordinary array length constraints.
Typed `ObjectPolicy.variant` declarations derive the runtime array selectors;
required literal discriminators must distinguish the reviewed object branches.
Runtime validation checks discriminator types before coercion so selection in
the parsed model agrees with selection in the original payload. Integer `1`,
boolean `true`, and floating-point `1.0` are not interchangeable selectors.
Generic JSON Schema does not express this Python type strictness.
For example, Responses can retain reasoning items while requiring exactly one
assistant message. Generic JSON Schema validators ignore this guard annotation;
they do not enforce selected-variant cardinality without policy-aware handling.
`stream_selector_field` names a boolean request field: true selects streaming;
false or null selects buffered output, with null allowed only when the field's
schema permits it. Omission follows the declared default. This marker does not
enable streaming support or make a field nullable.
The exporter requires a strict boolean selector with a literal default (or a
required field). Custom mode-selection properties, selector validators, and
default factories are runtime-only, even when no selector is named.

Numeric restrictions use the standard `minimum` and `maximum` assertions.
Python strictness has no JSON Schema keyword and is a stated limitation, not an
export failure: JSON Schema cannot distinguish an integer token from an
integral floating-point token. Runtime constraints do not have to be
exportable to construct a binding.

A stream's `oneOf` branches describe event families: `guarded_delta`, `snapshot`,
`opaque`, or `provider_error`. Their variants identify source schemas, matching
rules, and classifier shape names. An event variant `match` key is a
dot-separated member path from the event payload root, such as `error.type`,
so a provider member whose name contains a dot cannot be matched. An object
`variant` `match` key names a member of the candidate item directly. Both
compare the exact parsed type and value, so `1`, `1.0`, and `true` are
distinct. Missing-text policy is distinct from schema nullability. Transport
metadata describes SSE discriminators and sentinels.
The standard stream exporter rejects custom Python validators instead of
presenting their result as an equivalent declarative policy. Runtime stream
classification independently rejects validation that changes the original text.
Event exclusions and external-source reasons record scope and provenance; they
do not establish that every provider event has been reviewed.

Stateful event ordering, lifecycle checks, conditional replacement, and native
error encoding remain implementation behavior. Endpoint symbol references are
descriptive metadata, not instructions to load code from an untrusted document.

## Validation and stability

[guard-contract.schema.json](guard-contract.schema.json) validates the document
format and rejects unsupported keys in the reserved guardrail vocabulary. Other
`x-*` schema annotations are allowed. The schema can be associated with
`*.guard.yaml` in a JSON Schema-aware editor.

Format validation does not establish complete provider coverage, correct text
extraction, preservation of unrelated data, or equivalence to arbitrary Python
validators and coercion. These require implementation and source-aware tests.
Provider revision and digest checks are separate from document validation.

The format is experimental: `1.0.0-alpha.1`, not stable version 1. Its version
is separate from the capability profile `single_text.v1` and provider API
revision. A profile identifies the supported content capability; it does not
choose deployment rails or enable runtime profile selection.

This is a NeMo Guardrails document using JSON Schema vocabulary, not an OpenAPI
document or an OpenAPI Overlay. Generic schema tools do not execute its guardrail
annotations.

## Provider boundaries

- [OpenAI Chat Completions](openai/README.md)
