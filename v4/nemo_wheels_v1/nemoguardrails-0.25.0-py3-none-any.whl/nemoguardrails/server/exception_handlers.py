# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import logging
from typing import Dict, Optional, Union

from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.utils import is_body_allowed_for_status_code
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.responses import JSONResponse, Response

from nemoguardrails.exceptions import (
    InvalidCheckRequestError,
    InvalidStateError,
    LLMCallException,
    LLMRateLimitError,
    LLMResponseValidationError,
    RailTypeNotConfiguredError,
    RailTypeNotSupportedError,
    StreamingCapacityExceededError,
    StreamingNotSupportedError,
    ToolConversationTooLongError,
)
from nemoguardrails.guardrails.model_engine import ModelEngineError
from nemoguardrails.http.errors import HTTPClientError, HTTPStatusError
from nemoguardrails.llm.clients._errors import (
    as_client_error,
    build_error_payload,
    client_facing_message,
    normalize_error_status,
)
from nemoguardrails.llm.models.initializer import ModelInitializationError

log = logging.getLogger(__name__)

# How long an overloaded server asks a client to wait before retrying. Long
# enough that a rejected caller does not immediately add to the overload.
NONSTREAMING_RETRY_AFTER_SECONDS = 30
STREAMING_RETRY_AFTER_SECONDS = 30


def _error_response(
    status_code: int,
    message: str,
    error_type: Optional[str] = None,
    *,
    code: Union[str, int, None] = None,
    param: Optional[str] = None,
    headers: Optional[Dict[str, str]] = None,
) -> JSONResponse:
    """Render the shared OpenAI error envelope as a JSON HTTP response."""
    return JSONResponse(
        status_code=status_code,
        content=build_error_payload(message, status=status_code, error_type=error_type, code=code, param=param),
        headers=headers,
    )


def _client_error_details(exc: BaseException) -> tuple[str, Union[str, int, None], Optional[str], Dict[str, str]]:
    """Extract the client-facing message and the OpenAI error fields from an exception.

    ``code`` and ``param`` come from the provider when it supplied them, and a
    rate limit forwards its ``Retry-After`` so SDK backoff is not blind.
    """
    client_error = as_client_error(exc)
    if client_error is None:
        return client_facing_message(exc), None, None, {}

    headers: Dict[str, str] = {}
    retry_after = getattr(client_error, "retry_after_seconds", None)
    if isinstance(client_error, LLMRateLimitError) and retry_after is not None:
        headers["retry-after"] = str(int(max(retry_after, 0)))

    return client_facing_message(exc), client_error.error_code, client_error.param, headers


def _upstream_status(exc: BaseException) -> Optional[int]:
    """Read the upstream HTTP status off an exception, wherever that exception keeps it."""
    # HTTPStatusError carries the status on its response rather than as ``.status``, so without
    # this branch a vendor HTTP failure would still reach the caller as a generic 500 -- the
    # gap registering ``HTTPClientError`` in ``_EXCEPTION_HANDLERS`` exists to close.
    if isinstance(exc, HTTPStatusError):
        return exc.response.status_code
    return getattr(exc, "status", None)


async def llm_call_exception_handler(
    request: Request, exc: Union[LLMCallException, ModelEngineError, HTTPClientError, LLMResponseValidationError]
) -> Response:
    """Map provider failures to their HTTP status, or 502 for invalid responses."""
    log.exception(exc)
    if isinstance(as_client_error(exc), LLMResponseValidationError):
        status = 502
    else:
        status = normalize_error_status(_upstream_status(exc))
    message, code, param, headers = _client_error_details(exc)
    return _error_response(status, message, code=code, param=param, headers=headers or None)


async def model_initialization_error_handler(request: Request, exc: ModelInitializationError) -> Response:
    """Return 400 when a model fails to initialize from the configuration."""
    log.exception(exc)
    return _error_response(400, str(exc))


async def bad_request_error_handler(request: Request, exc: StreamingNotSupportedError) -> Response:
    """Return 400 for request/config combinations the caller can correct.

    These carry an actionable message (for example "enable streaming output
    rails"), so they must not fall through to the 500 catch-all, which would
    both hide the message and invite an SDK retry.
    """
    log.warning("Bad request: %s", exc)
    return _error_response(400, str(exc))


async def rail_type_not_configured_error_handler(request: Request, exc: RailTypeNotConfiguredError) -> Response:
    log.warning("Rail type not configured: %s", exc)
    return _error_response(422, str(exc))


async def rail_type_not_supported_error_handler(request: Request, exc: RailTypeNotSupportedError) -> Response:
    log.warning("Rail type not supported: %s", exc)
    return _error_response(422, str(exc))


async def invalid_check_request_error_handler(request: Request, exc: InvalidCheckRequestError) -> Response:
    log.warning("Invalid check request: %s", exc)
    return _error_response(422, str(exc))


async def invalid_state_error_handler(request: Request, exc: InvalidStateError) -> Response:
    log.warning("Invalid state: %s", exc)
    return _error_response(422, str(exc))


async def tool_conversation_too_long_error_handler(request: Request, exc: ToolConversationTooLongError) -> Response:
    """Return the standard 422 error envelope with a messages parameter and stable size-error code."""
    log.warning("Tool conversation rejected: %s", exc)
    return _error_response(422, str(exc), code="tool_conversation_too_long", param="messages")


async def validation_error_handler(request: Request, exc: RequestValidationError) -> Response:
    """Return 422 for request body validation failures.

    Only the field locations and messages are reported. ``str(exc)`` is the repr
    of pydantic's error list, which embeds the raw request body (prompts,
    tokens, PII), so it must reach neither the client nor the server log.
    """
    errors = exc.errors()
    summary = "; ".join(
        f"{'.'.join(str(part) for part in error.get('loc', ()))}: {error.get('msg', '')}" for error in errors
    )
    log.error("Request validation failed: %s", summary)
    first_loc = errors[0].get("loc") if errors else None
    if first_loc and first_loc[0] == "body":
        # OpenAI reports the field name alone (`model`, not `body.model`).
        first_loc = first_loc[1:]
    param = ".".join(str(part) for part in first_loc) if first_loc else None
    return _error_response(422, summary or "Request validation failed", param=param)


async def http_exception_handler(request: Request, exc: StarletteHTTPException) -> Response:
    """Render HTTPException (404, 422 guards, upstream 502, etc.) as the error envelope.

    ``exc.headers`` is forwarded because HTTP requires some of them (``Allow``
    on 405, ``WWW-Authenticate`` on 401), and statuses that disallow a body get
    an empty response rather than an envelope.
    """
    log.info("HTTP %s: %s", exc.status_code, exc.detail)
    headers = getattr(exc, "headers", None)
    if not is_body_allowed_for_status_code(exc.status_code):
        return Response(status_code=exc.status_code, headers=headers)
    return _error_response(exc.status_code, str(exc.detail), headers=headers)


async def internal_error_handler(request: Request, exc: Exception) -> Response:
    """Catch-all for unexpected errors."""
    log.exception(exc)
    return _error_response(500, "Internal server error")


async def queue_full_error_handler(request: Request, exc: asyncio.QueueFull) -> Response:
    """Render IORails admission shedding as a retryable overload response."""
    log.warning("IORails admission queue is full: %s", exc)
    return _error_response(
        503,
        "IORails admission queue is full. Please retry later.",
        code="queue_full",
        headers={"retry-after": str(NONSTREAMING_RETRY_AFTER_SECONDS)},
    )


async def streaming_capacity_error_handler(request: Request, exc: StreamingCapacityExceededError) -> Response:
    """Render IORails streaming capacity shedding as a retryable overload response.

    A full streaming semaphore is a different condition from a full admission
    queue, so it gets its own message rather than reporting the queue.
    """
    log.warning("IORails streaming capacity reached: %s", exc)
    return _error_response(
        503,
        "IORails streaming capacity is reached. Please retry later.",
        code="streaming_capacity",
        headers={"retry-after": str(STREAMING_RETRY_AFTER_SECONDS)},
    )
