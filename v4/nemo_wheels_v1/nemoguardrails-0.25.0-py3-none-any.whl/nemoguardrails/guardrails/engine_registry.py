# SPDX-FileCopyrightText: Copyright (c) 2023-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Engine registry for IORails: one ModelEngine per configured model type."""

import asyncio
import logging
from collections.abc import AsyncGenerator
from typing import TYPE_CHECKING, Any, Optional, TypeVar

from nemoguardrails.guardrails._lifecycle import rollback_startup
from nemoguardrails.guardrails.base_engine import BaseEngine
from nemoguardrails.guardrails.guardrails_types import get_request_id, truncate
from nemoguardrails.guardrails.model_engine import ModelEngine
from nemoguardrails.guardrails.tool_schema import LatestToolCall, ToolExchange, ToolResult, Toolset
from nemoguardrails.rails.llm.config import Model
from nemoguardrails.types import LLMModel, LLMResponse, LLMResponseChunk

if TYPE_CHECKING:
    from opentelemetry.trace import Tracer

log = logging.getLogger(__name__)

_EngineT = TypeVar("_EngineT", bound=BaseEngine)


class EngineRegistry:
    """One ModelEngine per configured model, keyed by model type."""

    def __init__(
        self,
        models: list[Model],
        tracer: Optional["Tracer"] = None,
        metrics_enabled: bool = False,
        content_capture_enabled: bool = False,
    ) -> None:
        """Build one engine per configured model, handing each the three telemetry settings."""
        # ModelEngine owns the instrumentation, so a rail reaching the model through
        # generate_async emits the same spans and metrics as main generation through model_call.
        self._engines: dict[str, BaseEngine] = {}
        self._llms: dict[str, LLMModel] = {}
        self._running = False
        self._owned_engines: dict[str, BaseEngine] = {}
        self._lifecycle_lock = asyncio.Lock()
        self._tracer = tracer

        for model_config in models:
            engine = ModelEngine(
                model_config,
                tracer=tracer,
                metrics_enabled=metrics_enabled,
                content_capture_enabled=content_capture_enabled,
            )
            self._engines[model_config.type] = engine
            self._llms[model_config.type] = engine
            log.info(
                "Registered model engine: type=%s, model=%s, base_url=%s",
                model_config.type,
                model_config.model,
                engine.base_url,
            )

    @property
    def llms(self) -> dict[str, LLMModel]:
        """The configured model engines keyed by ``Model.type``.

        This is the ``Dict[str, LLMModel]`` that library rail actions index by
        model type (``llms["content_safety"]``).  API engines are not LLMs and
        are excluded.
        """
        return self._llms

    async def start(self) -> None:
        """Start all engine clients.

        Failure or cancellation attempts bounded rollback, including the engine
        whose start was interrupted. Unfinished cleanup must complete before
        starting again; it can also be retried explicitly with stop().
        """
        async with self._lifecycle_lock:
            await self._start()

    async def _start(self) -> None:
        if self._running:
            return

        if self._owned_engines:
            await self._stop()
        for name, engine in self._engines.items():
            self._owned_engines[name] = engine
            try:
                await engine.start()
            except BaseException as e:
                await rollback_startup(self._stop)
                if isinstance(e, Exception):
                    log.error("Error starting engine %s: %s", name, e)
                    raise RuntimeError(f"Failed to start engine: Engine {name}: exception {e}") from e
                raise

        self._running = True

    async def stop(self) -> None:
        """Stop all engine clients.

        Successful closes are forgotten; failed or interrupted closes remain
        owned for retry. Ordinary failures do not prevent other engines from
        closing. Cancellation propagates without claiming cleanup completed.
        """
        async with self._lifecycle_lock:
            await self._stop()

    async def _stop(self) -> None:
        self._running = False
        errors: dict[str, Exception] = {}
        interruption: BaseException | None = None
        for name, engine in tuple(self._owned_engines.items()):
            try:
                await engine.stop()
            except BaseException as e:
                if isinstance(e, Exception):
                    errors[f"Engine {name}"] = e
                    log.error("Error stopping engine %s: %s", name, e)
                elif interruption is None:
                    interruption = e
            else:
                self._owned_engines.pop(name, None)

        if interruption is not None:
            raise interruption
        if errors:
            error_string = ", ".join(f"{component}: exception {exception}" for component, exception in errors.items())
            raise RuntimeError(f"Failed to stop engines: {error_string}")

    def _get_engine(self, name: str, expected_type: type[_EngineT]) -> _EngineT:
        """Look up an engine by name, verifying its type."""
        if name not in self._engines:
            available = list(self._engines.keys())
            raise KeyError(f"No engine configured with name '{name}'. Available: {available}")
        engine = self._engines[name]
        if not isinstance(engine, expected_type):
            raise TypeError(f"Engine '{name}' is {type(engine).__name__}, expected {expected_type.__name__}")
        return engine

    def provider_name(self, model_type: str) -> str:
        """Return the provider/engine name (e.g. 'nim', 'openai') for a model engine."""
        return self._get_engine(model_type, ModelEngine).provider_name

    async def model_call(self, model_type: str, messages: list[dict], **kwargs: Any) -> LLMResponse:
        """Route a chat completion request to the named model engine.

        Returns the structured ``LLMResponse`` from the engine — content,
        reasoning (when the provider exposes it), usage, finish reason.
        Callers that only want the assistant text should access ``.content``.

        Parameter merging and OTEL instrumentation live in
        ``ModelEngine.generate_from_messages`` so that rails, which reach the
        model through ``llm_call`` rather than through this method, emit the
        same spans and metrics.  *messages* is already in wire form here — every
        IORails entry point normalizes through ``IORails._convert_to_messages``
        — so this skips the ``generate_async`` protocol adapter.

        Raises:
            KeyError: If no engine is registered with the given name.
            TypeError: If the named engine is not a ModelEngine.
        """
        req_id = get_request_id()
        log.debug("[%s] Model engine '%s' messages: %s", req_id, model_type, truncate(messages))

        engine = self._get_engine(model_type, ModelEngine)
        result = await engine.generate_from_messages(messages, **kwargs)

        log.debug("[%s] Model engine '%s' response: %s", req_id, model_type, truncate(result))
        return result

    async def stream_model_call(
        self, model_type: str, messages: list[dict], **kwargs: Any
    ) -> AsyncGenerator[LLMResponseChunk, None]:
        """Stream chat completion chunks from the named model engine.

        Yields ``LLMResponseChunk`` objects.  Parameter merging, the LLM
        CLIENT span, and the metrics live in
        ``ModelEngine.stream_from_messages`` — see that method for the span and
        metric contract.  As in ``model_call``, *messages* is already in wire
        form, so this skips the ``stream_async`` protocol adapter.

        Raises:
            KeyError: If no engine is registered with the given name.
            TypeError: If the named engine is not a ModelEngine.
        """
        req_id = get_request_id()
        log.debug("[%s] Model engine '%s' stream messages: %s", req_id, model_type, truncate(messages))

        engine = self._get_engine(model_type, ModelEngine)
        stream = engine.stream_from_messages(messages, **kwargs)
        try:
            async for chunk in stream:
                yield chunk
        finally:
            # Close the delegate explicitly.  A consumer that abandons this
            # generator only unwinds *this* one; without the aclose the
            # instrumented core stays suspended at its yield until garbage
            # collection, so the duration metric's `finally` never runs.
            await stream.aclose()

    def parse_tools(self, model_type: str, llm_params: Optional[dict]) -> Toolset:
        """Parse the tool block in ``llm_params`` for the named model engine.

        Delegates to the engine's ``parse_tools`` so the provider-specific shape
        (keyed on the engine) is normalized into a ``Toolset`` for the tool rails.

        Raises:
            KeyError: If no engine is registered with the given name.
            TypeError: If the named engine is not a ModelEngine.
        """
        engine = self._get_engine(model_type, ModelEngine)
        return engine.parse_tools({**engine.body_param_defaults, **(llm_params or {})})

    def extract_tool_results(self, model_type: str, messages: list[dict]) -> list[ToolResult]:
        """Extract incoming tool results from ``messages`` for the named model engine.

        Delegates to the engine's ``extract_tool_results`` so the provider's
        tool-result messages are normalized into the ``ToolResult`` list the
        ToolResultRail consumes.

        Raises:
            KeyError: If no engine is registered with the given name.
            TypeError: If the named engine is not a ModelEngine.
        """
        engine = self._get_engine(model_type, ModelEngine)
        return engine.extract_tool_results(messages)

    def extract_tool_exchanges(self, model_type: str, messages: list[dict]) -> list[ToolExchange]:
        """Group ``messages`` into per-turn ``(tool_calls, tool_results)`` exchanges.

        Delegates to the engine's ``extract_tool_exchanges`` so each tool result is
        validated against its own turn's calls. This keeps ``call_id`` linkage
        turn-local, which ``RailsManager.are_tool_results_safe`` relies on so that ids
        reused across turns (spec-allowed) are not flagged as ambiguous duplicates.

        Raises:
            KeyError: If no engine is registered with the given name.
            TypeError: If the named engine is not a ModelEngine.
        """
        engine = self._get_engine(model_type, ModelEngine)
        return engine.extract_tool_exchanges(messages)

    def extract_latest_tool_calls(self, model_type: str, messages: list[dict]) -> list[LatestToolCall]:
        """Strictly parse the last assistant message's tool calls with the named model engine."""
        engine = self._get_engine(model_type, ModelEngine)
        return engine.extract_latest_tool_calls(messages)

    async def __aenter__(self):
        """Async context manager entry: start all engine clients."""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit: stop all engine clients."""
        await self.stop()
